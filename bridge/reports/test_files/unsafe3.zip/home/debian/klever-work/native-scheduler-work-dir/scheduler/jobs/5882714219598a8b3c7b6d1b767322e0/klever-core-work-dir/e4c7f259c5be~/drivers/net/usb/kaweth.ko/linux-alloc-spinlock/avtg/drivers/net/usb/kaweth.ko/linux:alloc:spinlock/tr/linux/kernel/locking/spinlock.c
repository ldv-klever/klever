/*
 * Copyright (c) 2014-2016 ISPRAS (http://www.ispras.ru)
 * Institute for System Programming of the Russian Academy of Sciences
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * ee the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <linux/ldv/common.h>
#include <verifier/common.h>
#include <verifier/nondet.h>

static int ldv_spin__xmit_lock_of_netdev_queue = 1;

/* MODEL_FUNC Check that spinlock "_xmit_lock_of_netdev_queue" was not locked and lock it */
void ldv_spin_lock__xmit_lock_of_netdev_queue(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Lock spinlock "_xmit_lock_of_netdev_queue" */
	ldv_spin__xmit_lock_of_netdev_queue = 2;
}

/* MODEL_FUNC Check that spinlock "_xmit_lock_of_netdev_queue" was locked and unlock it */
void ldv_spin_unlock__xmit_lock_of_netdev_queue(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin__xmit_lock_of_netdev_queue == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 2);
	/* NOTE Unlock spinlock "_xmit_lock_of_netdev_queue" */
	ldv_spin__xmit_lock_of_netdev_queue = 1;
}

/* MODEL_FUNC Check that spinlock "_xmit_lock_of_netdev_queue" was not locked and nondeterministically lock it */
int ldv_spin_trylock__xmit_lock_of_netdev_queue(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "_xmit_lock_of_netdev_queue" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "_xmit_lock_of_netdev_queue" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "_xmit_lock_of_netdev_queue" */
		ldv_spin__xmit_lock_of_netdev_queue = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "_xmit_lock_of_netdev_queue" and wait until it will be unlocked */
void ldv_spin_unlock_wait__xmit_lock_of_netdev_queue(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);
}

/* MODEL_FUNC Check whether spinlock "_xmit_lock_of_netdev_queue" was locked */
int ldv_spin_is_locked__xmit_lock_of_netdev_queue(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "_xmit_lock_of_netdev_queue" was locked */
	if(ldv_spin__xmit_lock_of_netdev_queue == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "_xmit_lock_of_netdev_queue" was not locked */
int ldv_spin_can_lock__xmit_lock_of_netdev_queue(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked__xmit_lock_of_netdev_queue();
}

/* MODEL_FUNC Check whether spinlock "_xmit_lock_of_netdev_queue" is contended */
int ldv_spin_is_contended__xmit_lock_of_netdev_queue(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "_xmit_lock_of_netdev_queue" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "_xmit_lock_of_netdev_queue" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock__xmit_lock_of_netdev_queue(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "_xmit_lock_of_netdev_queue" */
		ldv_spin__xmit_lock_of_netdev_queue = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "_xmit_lock_of_netdev_queue" */
	return 0;
}
static int ldv_spin_addr_list_lock_of_net_device = 1;

/* MODEL_FUNC Check that spinlock "addr_list_lock_of_net_device" was not locked and lock it */
void ldv_spin_lock_addr_list_lock_of_net_device(void)
{
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Lock spinlock "addr_list_lock_of_net_device" */
	ldv_spin_addr_list_lock_of_net_device = 2;
}

/* MODEL_FUNC Check that spinlock "addr_list_lock_of_net_device" was locked and unlock it */
void ldv_spin_unlock_addr_list_lock_of_net_device(void)
{
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_addr_list_lock_of_net_device == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 2);
	/* NOTE Unlock spinlock "addr_list_lock_of_net_device" */
	ldv_spin_addr_list_lock_of_net_device = 1;
}

/* MODEL_FUNC Check that spinlock "addr_list_lock_of_net_device" was not locked and nondeterministically lock it */
int ldv_spin_trylock_addr_list_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "addr_list_lock_of_net_device" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "addr_list_lock_of_net_device" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "addr_list_lock_of_net_device" */
		ldv_spin_addr_list_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "addr_list_lock_of_net_device" and wait until it will be unlocked */
void ldv_spin_unlock_wait_addr_list_lock_of_net_device(void)
{
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);
}

/* MODEL_FUNC Check whether spinlock "addr_list_lock_of_net_device" was locked */
int ldv_spin_is_locked_addr_list_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "addr_list_lock_of_net_device" was locked */
	if(ldv_spin_addr_list_lock_of_net_device == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "addr_list_lock_of_net_device" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "addr_list_lock_of_net_device" was not locked */
int ldv_spin_can_lock_addr_list_lock_of_net_device(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_addr_list_lock_of_net_device();
}

/* MODEL_FUNC Check whether spinlock "addr_list_lock_of_net_device" is contended */
int ldv_spin_is_contended_addr_list_lock_of_net_device(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "addr_list_lock_of_net_device" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "addr_list_lock_of_net_device" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_addr_list_lock_of_net_device(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "addr_list_lock_of_net_device" */
		ldv_spin_addr_list_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "addr_list_lock_of_net_device" */
	return 0;
}
static int ldv_spin_alloc_lock_of_task_struct = 1;

/* MODEL_FUNC Check that spinlock "alloc_lock_of_task_struct" was not locked and lock it */
void ldv_spin_lock_alloc_lock_of_task_struct(void)
{
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Lock spinlock "alloc_lock_of_task_struct" */
	ldv_spin_alloc_lock_of_task_struct = 2;
}

/* MODEL_FUNC Check that spinlock "alloc_lock_of_task_struct" was locked and unlock it */
void ldv_spin_unlock_alloc_lock_of_task_struct(void)
{
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_alloc_lock_of_task_struct == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 2);
	/* NOTE Unlock spinlock "alloc_lock_of_task_struct" */
	ldv_spin_alloc_lock_of_task_struct = 1;
}

/* MODEL_FUNC Check that spinlock "alloc_lock_of_task_struct" was not locked and nondeterministically lock it */
int ldv_spin_trylock_alloc_lock_of_task_struct(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "alloc_lock_of_task_struct" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "alloc_lock_of_task_struct" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "alloc_lock_of_task_struct" */
		ldv_spin_alloc_lock_of_task_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "alloc_lock_of_task_struct" and wait until it will be unlocked */
void ldv_spin_unlock_wait_alloc_lock_of_task_struct(void)
{
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);
}

/* MODEL_FUNC Check whether spinlock "alloc_lock_of_task_struct" was locked */
int ldv_spin_is_locked_alloc_lock_of_task_struct(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "alloc_lock_of_task_struct" was locked */
	if(ldv_spin_alloc_lock_of_task_struct == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "alloc_lock_of_task_struct" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "alloc_lock_of_task_struct" was not locked */
int ldv_spin_can_lock_alloc_lock_of_task_struct(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_alloc_lock_of_task_struct();
}

/* MODEL_FUNC Check whether spinlock "alloc_lock_of_task_struct" is contended */
int ldv_spin_is_contended_alloc_lock_of_task_struct(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "alloc_lock_of_task_struct" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "alloc_lock_of_task_struct" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_alloc_lock_of_task_struct(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "alloc_lock_of_task_struct" */
		ldv_spin_alloc_lock_of_task_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "alloc_lock_of_task_struct" */
	return 0;
}
static int ldv_spin_d_lock_of_dentry = 1;

/* MODEL_FUNC Check that spinlock "d_lock_of_dentry" was not locked and lock it */
void ldv_spin_lock_d_lock_of_dentry(void)
{
	/* ASSERT Spinlock "d_lock_of_dentry" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_d_lock_of_dentry == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_d_lock_of_dentry == 1);
	/* NOTE Lock spinlock "d_lock_of_dentry" */
	ldv_spin_d_lock_of_dentry = 2;
}

/* MODEL_FUNC Check that spinlock "d_lock_of_dentry" was locked and unlock it */
void ldv_spin_unlock_d_lock_of_dentry(void)
{
	/* ASSERT Spinlock "d_lock_of_dentry" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_d_lock_of_dentry == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_d_lock_of_dentry == 2);
	/* NOTE Unlock spinlock "d_lock_of_dentry" */
	ldv_spin_d_lock_of_dentry = 1;
}

/* MODEL_FUNC Check that spinlock "d_lock_of_dentry" was not locked and nondeterministically lock it */
int ldv_spin_trylock_d_lock_of_dentry(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "d_lock_of_dentry" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_d_lock_of_dentry == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_d_lock_of_dentry == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "d_lock_of_dentry" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "d_lock_of_dentry" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "d_lock_of_dentry" */
		ldv_spin_d_lock_of_dentry = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "d_lock_of_dentry" and wait until it will be unlocked */
void ldv_spin_unlock_wait_d_lock_of_dentry(void)
{
	/* ASSERT Spinlock "d_lock_of_dentry" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_d_lock_of_dentry == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_d_lock_of_dentry == 1);
}

/* MODEL_FUNC Check whether spinlock "d_lock_of_dentry" was locked */
int ldv_spin_is_locked_d_lock_of_dentry(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "d_lock_of_dentry" was locked */
	if(ldv_spin_d_lock_of_dentry == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "d_lock_of_dentry" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "d_lock_of_dentry" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "d_lock_of_dentry" was not locked */
int ldv_spin_can_lock_d_lock_of_dentry(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_d_lock_of_dentry();
}

/* MODEL_FUNC Check whether spinlock "d_lock_of_dentry" is contended */
int ldv_spin_is_contended_d_lock_of_dentry(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "d_lock_of_dentry" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "d_lock_of_dentry" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "d_lock_of_dentry" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "d_lock_of_dentry" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_d_lock_of_dentry(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "d_lock_of_dentry" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_d_lock_of_dentry == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_d_lock_of_dentry == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "d_lock_of_dentry" */
		ldv_spin_d_lock_of_dentry = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "d_lock_of_dentry" */
	return 0;
}
static int ldv_spin_device_lock_of_kaweth_device = 1;

/* MODEL_FUNC Check that spinlock "device_lock_of_kaweth_device" was not locked and lock it */
void ldv_spin_lock_device_lock_of_kaweth_device(void)
{
	/* ASSERT Spinlock "device_lock_of_kaweth_device" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_device_lock_of_kaweth_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_device_lock_of_kaweth_device == 1);
	/* NOTE Lock spinlock "device_lock_of_kaweth_device" */
	ldv_spin_device_lock_of_kaweth_device = 2;
}

/* MODEL_FUNC Check that spinlock "device_lock_of_kaweth_device" was locked and unlock it */
void ldv_spin_unlock_device_lock_of_kaweth_device(void)
{
	/* ASSERT Spinlock "device_lock_of_kaweth_device" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_device_lock_of_kaweth_device == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_device_lock_of_kaweth_device == 2);
	/* NOTE Unlock spinlock "device_lock_of_kaweth_device" */
	ldv_spin_device_lock_of_kaweth_device = 1;
}

/* MODEL_FUNC Check that spinlock "device_lock_of_kaweth_device" was not locked and nondeterministically lock it */
int ldv_spin_trylock_device_lock_of_kaweth_device(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "device_lock_of_kaweth_device" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_device_lock_of_kaweth_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_device_lock_of_kaweth_device == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "device_lock_of_kaweth_device" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "device_lock_of_kaweth_device" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "device_lock_of_kaweth_device" */
		ldv_spin_device_lock_of_kaweth_device = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "device_lock_of_kaweth_device" and wait until it will be unlocked */
void ldv_spin_unlock_wait_device_lock_of_kaweth_device(void)
{
	/* ASSERT Spinlock "device_lock_of_kaweth_device" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_device_lock_of_kaweth_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_device_lock_of_kaweth_device == 1);
}

/* MODEL_FUNC Check whether spinlock "device_lock_of_kaweth_device" was locked */
int ldv_spin_is_locked_device_lock_of_kaweth_device(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "device_lock_of_kaweth_device" was locked */
	if(ldv_spin_device_lock_of_kaweth_device == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "device_lock_of_kaweth_device" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "device_lock_of_kaweth_device" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "device_lock_of_kaweth_device" was not locked */
int ldv_spin_can_lock_device_lock_of_kaweth_device(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_device_lock_of_kaweth_device();
}

/* MODEL_FUNC Check whether spinlock "device_lock_of_kaweth_device" is contended */
int ldv_spin_is_contended_device_lock_of_kaweth_device(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "device_lock_of_kaweth_device" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "device_lock_of_kaweth_device" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "device_lock_of_kaweth_device" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "device_lock_of_kaweth_device" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_device_lock_of_kaweth_device(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "device_lock_of_kaweth_device" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_device_lock_of_kaweth_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_device_lock_of_kaweth_device == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "device_lock_of_kaweth_device" */
		ldv_spin_device_lock_of_kaweth_device = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "device_lock_of_kaweth_device" */
	return 0;
}
static int ldv_spin_i_lock_of_inode = 1;

/* MODEL_FUNC Check that spinlock "i_lock_of_inode" was not locked and lock it */
void ldv_spin_lock_i_lock_of_inode(void)
{
	/* ASSERT Spinlock "i_lock_of_inode" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);
	/* NOTE Lock spinlock "i_lock_of_inode" */
	ldv_spin_i_lock_of_inode = 2;
}

/* MODEL_FUNC Check that spinlock "i_lock_of_inode" was locked and unlock it */
void ldv_spin_unlock_i_lock_of_inode(void)
{
	/* ASSERT Spinlock "i_lock_of_inode" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_i_lock_of_inode == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 2);
	/* NOTE Unlock spinlock "i_lock_of_inode" */
	ldv_spin_i_lock_of_inode = 1;
}

/* MODEL_FUNC Check that spinlock "i_lock_of_inode" was not locked and nondeterministically lock it */
int ldv_spin_trylock_i_lock_of_inode(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "i_lock_of_inode" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "i_lock_of_inode" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "i_lock_of_inode" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "i_lock_of_inode" */
		ldv_spin_i_lock_of_inode = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "i_lock_of_inode" and wait until it will be unlocked */
void ldv_spin_unlock_wait_i_lock_of_inode(void)
{
	/* ASSERT Spinlock "i_lock_of_inode" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);
}

/* MODEL_FUNC Check whether spinlock "i_lock_of_inode" was locked */
int ldv_spin_is_locked_i_lock_of_inode(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "i_lock_of_inode" was locked */
	if(ldv_spin_i_lock_of_inode == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "i_lock_of_inode" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "i_lock_of_inode" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "i_lock_of_inode" was not locked */
int ldv_spin_can_lock_i_lock_of_inode(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_i_lock_of_inode();
}

/* MODEL_FUNC Check whether spinlock "i_lock_of_inode" is contended */
int ldv_spin_is_contended_i_lock_of_inode(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "i_lock_of_inode" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "i_lock_of_inode" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "i_lock_of_inode" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "i_lock_of_inode" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_i_lock_of_inode(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "i_lock_of_inode" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "i_lock_of_inode" */
		ldv_spin_i_lock_of_inode = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "i_lock_of_inode" */
	return 0;
}
static int ldv_spin_lock_of_NOT_ARG_SIGN = 1;

/* MODEL_FUNC Check that spinlock "lock_of_NOT_ARG_SIGN" was not locked and lock it */
void ldv_spin_lock_lock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Lock spinlock "lock_of_NOT_ARG_SIGN" */
	ldv_spin_lock_of_NOT_ARG_SIGN = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_NOT_ARG_SIGN" was locked and unlock it */
void ldv_spin_unlock_lock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_NOT_ARG_SIGN == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 2);
	/* NOTE Unlock spinlock "lock_of_NOT_ARG_SIGN" */
	ldv_spin_lock_of_NOT_ARG_SIGN = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_NOT_ARG_SIGN" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_NOT_ARG_SIGN(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_NOT_ARG_SIGN" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_NOT_ARG_SIGN" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_NOT_ARG_SIGN" */
		ldv_spin_lock_of_NOT_ARG_SIGN = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_NOT_ARG_SIGN" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_NOT_ARG_SIGN" was locked */
int ldv_spin_is_locked_lock_of_NOT_ARG_SIGN(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_NOT_ARG_SIGN" was locked */
	if(ldv_spin_lock_of_NOT_ARG_SIGN == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_NOT_ARG_SIGN" was not locked */
int ldv_spin_can_lock_lock_of_NOT_ARG_SIGN(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_NOT_ARG_SIGN();
}

/* MODEL_FUNC Check whether spinlock "lock_of_NOT_ARG_SIGN" is contended */
int ldv_spin_is_contended_lock_of_NOT_ARG_SIGN(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_NOT_ARG_SIGN" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_NOT_ARG_SIGN" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_NOT_ARG_SIGN(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_NOT_ARG_SIGN" */
		ldv_spin_lock_of_NOT_ARG_SIGN = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_NOT_ARG_SIGN" */
	return 0;
}
static int ldv_spin_node_size_lock_of_pglist_data = 1;

/* MODEL_FUNC Check that spinlock "node_size_lock_of_pglist_data" was not locked and lock it */
void ldv_spin_lock_node_size_lock_of_pglist_data(void)
{
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Lock spinlock "node_size_lock_of_pglist_data" */
	ldv_spin_node_size_lock_of_pglist_data = 2;
}

/* MODEL_FUNC Check that spinlock "node_size_lock_of_pglist_data" was locked and unlock it */
void ldv_spin_unlock_node_size_lock_of_pglist_data(void)
{
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_node_size_lock_of_pglist_data == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 2);
	/* NOTE Unlock spinlock "node_size_lock_of_pglist_data" */
	ldv_spin_node_size_lock_of_pglist_data = 1;
}

/* MODEL_FUNC Check that spinlock "node_size_lock_of_pglist_data" was not locked and nondeterministically lock it */
int ldv_spin_trylock_node_size_lock_of_pglist_data(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "node_size_lock_of_pglist_data" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "node_size_lock_of_pglist_data" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "node_size_lock_of_pglist_data" */
		ldv_spin_node_size_lock_of_pglist_data = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "node_size_lock_of_pglist_data" and wait until it will be unlocked */
void ldv_spin_unlock_wait_node_size_lock_of_pglist_data(void)
{
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);
}

/* MODEL_FUNC Check whether spinlock "node_size_lock_of_pglist_data" was locked */
int ldv_spin_is_locked_node_size_lock_of_pglist_data(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "node_size_lock_of_pglist_data" was locked */
	if(ldv_spin_node_size_lock_of_pglist_data == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "node_size_lock_of_pglist_data" was not locked */
int ldv_spin_can_lock_node_size_lock_of_pglist_data(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_node_size_lock_of_pglist_data();
}

/* MODEL_FUNC Check whether spinlock "node_size_lock_of_pglist_data" is contended */
int ldv_spin_is_contended_node_size_lock_of_pglist_data(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "node_size_lock_of_pglist_data" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "node_size_lock_of_pglist_data" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_node_size_lock_of_pglist_data(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "node_size_lock_of_pglist_data" */
		ldv_spin_node_size_lock_of_pglist_data = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "node_size_lock_of_pglist_data" */
	return 0;
}
static int ldv_spin_siglock_of_sighand_struct = 1;

/* MODEL_FUNC Check that spinlock "siglock_of_sighand_struct" was not locked and lock it */
void ldv_spin_lock_siglock_of_sighand_struct(void)
{
	/* ASSERT Spinlock "siglock_of_sighand_struct" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Lock spinlock "siglock_of_sighand_struct" */
	ldv_spin_siglock_of_sighand_struct = 2;
}

/* MODEL_FUNC Check that spinlock "siglock_of_sighand_struct" was locked and unlock it */
void ldv_spin_unlock_siglock_of_sighand_struct(void)
{
	/* ASSERT Spinlock "siglock_of_sighand_struct" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_siglock_of_sighand_struct == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 2);
	/* NOTE Unlock spinlock "siglock_of_sighand_struct" */
	ldv_spin_siglock_of_sighand_struct = 1;
}

/* MODEL_FUNC Check that spinlock "siglock_of_sighand_struct" was not locked and nondeterministically lock it */
int ldv_spin_trylock_siglock_of_sighand_struct(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "siglock_of_sighand_struct" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "siglock_of_sighand_struct" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "siglock_of_sighand_struct" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "siglock_of_sighand_struct" */
		ldv_spin_siglock_of_sighand_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "siglock_of_sighand_struct" and wait until it will be unlocked */
void ldv_spin_unlock_wait_siglock_of_sighand_struct(void)
{
	/* ASSERT Spinlock "siglock_of_sighand_struct" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);
}

/* MODEL_FUNC Check whether spinlock "siglock_of_sighand_struct" was locked */
int ldv_spin_is_locked_siglock_of_sighand_struct(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "siglock_of_sighand_struct" was locked */
	if(ldv_spin_siglock_of_sighand_struct == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "siglock_of_sighand_struct" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "siglock_of_sighand_struct" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "siglock_of_sighand_struct" was not locked */
int ldv_spin_can_lock_siglock_of_sighand_struct(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_siglock_of_sighand_struct();
}

/* MODEL_FUNC Check whether spinlock "siglock_of_sighand_struct" is contended */
int ldv_spin_is_contended_siglock_of_sighand_struct(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "siglock_of_sighand_struct" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "siglock_of_sighand_struct" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "siglock_of_sighand_struct" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "siglock_of_sighand_struct" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_siglock_of_sighand_struct(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "siglock_of_sighand_struct" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "siglock_of_sighand_struct" */
		ldv_spin_siglock_of_sighand_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "siglock_of_sighand_struct" */
	return 0;
}
static int ldv_spin_tx_global_lock_of_net_device = 1;

/* MODEL_FUNC Check that spinlock "tx_global_lock_of_net_device" was not locked and lock it */
void ldv_spin_lock_tx_global_lock_of_net_device(void)
{
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Lock spinlock "tx_global_lock_of_net_device" */
	ldv_spin_tx_global_lock_of_net_device = 2;
}

/* MODEL_FUNC Check that spinlock "tx_global_lock_of_net_device" was locked and unlock it */
void ldv_spin_unlock_tx_global_lock_of_net_device(void)
{
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_tx_global_lock_of_net_device == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 2);
	/* NOTE Unlock spinlock "tx_global_lock_of_net_device" */
	ldv_spin_tx_global_lock_of_net_device = 1;
}

/* MODEL_FUNC Check that spinlock "tx_global_lock_of_net_device" was not locked and nondeterministically lock it */
int ldv_spin_trylock_tx_global_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "tx_global_lock_of_net_device" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "tx_global_lock_of_net_device" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "tx_global_lock_of_net_device" */
		ldv_spin_tx_global_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "tx_global_lock_of_net_device" and wait until it will be unlocked */
void ldv_spin_unlock_wait_tx_global_lock_of_net_device(void)
{
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);
}

/* MODEL_FUNC Check whether spinlock "tx_global_lock_of_net_device" was locked */
int ldv_spin_is_locked_tx_global_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "tx_global_lock_of_net_device" was locked */
	if(ldv_spin_tx_global_lock_of_net_device == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "tx_global_lock_of_net_device" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "tx_global_lock_of_net_device" was not locked */
int ldv_spin_can_lock_tx_global_lock_of_net_device(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_tx_global_lock_of_net_device();
}

/* MODEL_FUNC Check whether spinlock "tx_global_lock_of_net_device" is contended */
int ldv_spin_is_contended_tx_global_lock_of_net_device(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "tx_global_lock_of_net_device" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "tx_global_lock_of_net_device" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_tx_global_lock_of_net_device(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "tx_global_lock_of_net_device" */
		ldv_spin_tx_global_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "tx_global_lock_of_net_device" */
	return 0;
}
/* MODEL_FUNC Check that all spinlocks are unlocked at the end */
void ldv_check_final_state(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_addr_list_lock_of_net_device == 1);
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_alloc_lock_of_task_struct == 1);
	/* ASSERT Spinlock "d_lock_of_dentry" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_d_lock_of_dentry == 1);
	/* ASSERT Spinlock "device_lock_of_kaweth_device" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_device_lock_of_kaweth_device == 1);
	/* ASSERT Spinlock "i_lock_of_inode" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_i_lock_of_inode == 1);
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* ASSERT Spinlock "siglock_of_sighand_struct" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_siglock_of_sighand_struct == 1);
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_tx_global_lock_of_net_device == 1);
}

/* For 'linux:alloc:spinlock' rule */
int ldv_exclusive_spin_is_locked(void)
{
	/* NOTE Nondeterministically understand whether spinlock "_xmit_lock_of_netdev_queue" was locked */
	if(ldv_spin__xmit_lock_of_netdev_queue == 2) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "addr_list_lock_of_net_device" was locked */
	if(ldv_spin_addr_list_lock_of_net_device == 2) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "alloc_lock_of_task_struct" was locked */
	if(ldv_spin_alloc_lock_of_task_struct == 2) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "d_lock_of_dentry" was locked */
	if(ldv_spin_d_lock_of_dentry == 2) {
		/* NOTE Spinlock "d_lock_of_dentry" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "device_lock_of_kaweth_device" was locked */
	if(ldv_spin_device_lock_of_kaweth_device == 2) {
		/* NOTE Spinlock "device_lock_of_kaweth_device" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "i_lock_of_inode" was locked */
	if(ldv_spin_i_lock_of_inode == 2) {
		/* NOTE Spinlock "i_lock_of_inode" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_NOT_ARG_SIGN" was locked */
	if(ldv_spin_lock_of_NOT_ARG_SIGN == 2) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "node_size_lock_of_pglist_data" was locked */
	if(ldv_spin_node_size_lock_of_pglist_data == 2) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "siglock_of_sighand_struct" was locked */
	if(ldv_spin_siglock_of_sighand_struct == 2) {
		/* NOTE Spinlock "siglock_of_sighand_struct" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "tx_global_lock_of_net_device" was locked */
	if(ldv_spin_tx_global_lock_of_net_device == 2) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is locked */
		return 1;
	}
	/* NOTE None of the spinlocks are locked */
	return 0;
}