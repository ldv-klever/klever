/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_fs_char_dev__double_deregistration(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_fs_char_dev__double_registration(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_fs_char_dev__registered_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
