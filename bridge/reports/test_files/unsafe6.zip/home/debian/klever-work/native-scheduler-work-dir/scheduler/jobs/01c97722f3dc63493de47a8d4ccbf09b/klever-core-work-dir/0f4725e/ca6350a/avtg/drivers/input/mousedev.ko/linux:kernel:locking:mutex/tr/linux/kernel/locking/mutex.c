/*
 * Copyright (c) 2014-2016 ISPRAS (http://www.ispras.ru)
 * Institute for System Programming of the Russian Academy of Sciences
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * ee the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <linux/errno.h>
#include <linux/types.h>
#include <linux/ldv/common.h>
#include <verifier/common.h>
#include <verifier/nondet.h>
#include <verifier/set.h>

struct mutex;

ldv_set LDV_MUTEXES_mousedev_table_mutex;

/* MODEL_FUNC Check that mutex "mousedev_table_mutex" was not locked and lock it */
void ldv_mutex_lock_mousedev_table_mutex(struct mutex *lock)
{
	/* ASSERT Mutex "mousedev_table_mutex" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_mousedev_table_mutex, lock));
	/* NOTE Lock mutex "mousedev_table_mutex" */
	ldv_set_add(LDV_MUTEXES_mousedev_table_mutex, lock);
}

/* MODEL_FUNC Check that mutex "mousedev_table_mutex" was not locked and nondeterministically lock it */
int ldv_mutex_lock_interruptible_or_killable_mousedev_table_mutex(struct mutex *lock)
{
	/* ASSERT Mutex "mousedev_table_mutex" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_mousedev_table_mutex, lock));
	/* NOTE Nondeterministically lock mutex "mousedev_table_mutex" */
	if (ldv_undef_int()) {
		/* NOTE Lock mutex "mousedev_table_mutex" */
		ldv_set_add(LDV_MUTEXES_mousedev_table_mutex, lock);
		/* NOTE Successfully locked mutex "mousedev_table_mutex" */
		return 0;
	}
	else {
		/* NOTE Could not lock mutex "mousedev_table_mutex" */
		return -EINTR;
	}
}

/* MODEL_FUNC Say whether mutex "mousedev_table_mutex" was locked in this or another thread  */
int ldv_mutex_is_locked_mousedev_table_mutex(struct mutex *lock)
{
	/* NOTE Whether mutex "mousedev_table_mutex" was locked in this thread */
	if (ldv_set_contains(LDV_MUTEXES_mousedev_table_mutex, lock)) {
		/* NOTE Mutex "mousedev_table_mutex" was locked in this thread */
		return 1;
	}
	/* NOTE Nondeterministically decide whether mutex "mousedev_table_mutex" was locked in another thread */
	else if (ldv_undef_int()) {
		/* NOTE Mutex "mousedev_table_mutex" was locked in another thread */
		return 1;
	}
	else {
		/* NOTE Mutex "mousedev_table_mutex" was not acquired in this or another thread */
		return 0;
	}
}

/* MODEL_FUNC Lock mutex "mousedev_table_mutex" if it was not locked before */
int ldv_mutex_trylock_mousedev_table_mutex(struct mutex *lock)
{
	/* ASSERT Mutex "mousedev_table_mutex" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock try", !ldv_set_contains(LDV_MUTEXES_mousedev_table_mutex, lock));

	/* NOTE Whether mutex "mousedev_table_mutex" was locked */
	if (ldv_mutex_is_locked_mousedev_table_mutex(lock)) {
		/* NOTE Mutex "mousedev_table_mutex" was locked */
		return 0;
	}
	else {
		/* NOTE Lock mutex "mousedev_table_mutex" */
		ldv_set_add(LDV_MUTEXES_mousedev_table_mutex, lock);
		/* NOTE Successfully locked mutex "mousedev_table_mutex" */
		return 1;
	}
}

/* MODEL_FUNC Decrease counter by one and if it becomes zero check that mutex "mousedev_table_mutex" was not locked and lock it */
int ldv_atomic_dec_and_mutex_lock_mousedev_table_mutex(atomic_t *cnt, struct mutex *lock)
{
	/* NOTE Decrease counter by one */
	cnt->counter--;

	/* NOTE Whether counter becomes zero */
	if (cnt->counter) {
		/* NOTE Do not lock mutex "mousedev_table_mutex" since counter is greater than zero */
		return 0;
	}
	else {
		ldv_mutex_lock_mousedev_table_mutex(lock);
		/* NOTE Successfully locked mutex "mousedev_table_mutex" */
		return 1;
	}
}

/* MODEL_FUNC Check that mutex "mousedev_table_mutex" was locked and unlock it */
void ldv_mutex_unlock_mousedev_table_mutex(struct mutex *lock)
{
	/* ASSERT Mutex "mousedev_table_mutex" must be locked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double unlock", ldv_set_contains(LDV_MUTEXES_mousedev_table_mutex, lock));
	/* NOTE Unlock mutex "mousedev_table_mutex" */
	ldv_set_remove(LDV_MUTEXES_mousedev_table_mutex, lock);
}
ldv_set LDV_MUTEXES_mutex_of_mousedev;

/* MODEL_FUNC Check that mutex "mutex_of_mousedev" was not locked and lock it */
void ldv_mutex_lock_mutex_of_mousedev(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_mousedev" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_mutex_of_mousedev, lock));
	/* NOTE Lock mutex "mutex_of_mousedev" */
	ldv_set_add(LDV_MUTEXES_mutex_of_mousedev, lock);
}

/* MODEL_FUNC Check that mutex "mutex_of_mousedev" was not locked and nondeterministically lock it */
int ldv_mutex_lock_interruptible_or_killable_mutex_of_mousedev(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_mousedev" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_mutex_of_mousedev, lock));
	/* NOTE Nondeterministically lock mutex "mutex_of_mousedev" */
	if (ldv_undef_int()) {
		/* NOTE Lock mutex "mutex_of_mousedev" */
		ldv_set_add(LDV_MUTEXES_mutex_of_mousedev, lock);
		/* NOTE Successfully locked mutex "mutex_of_mousedev" */
		return 0;
	}
	else {
		/* NOTE Could not lock mutex "mutex_of_mousedev" */
		return -EINTR;
	}
}

/* MODEL_FUNC Say whether mutex "mutex_of_mousedev" was locked in this or another thread  */
int ldv_mutex_is_locked_mutex_of_mousedev(struct mutex *lock)
{
	/* NOTE Whether mutex "mutex_of_mousedev" was locked in this thread */
	if (ldv_set_contains(LDV_MUTEXES_mutex_of_mousedev, lock)) {
		/* NOTE Mutex "mutex_of_mousedev" was locked in this thread */
		return 1;
	}
	/* NOTE Nondeterministically decide whether mutex "mutex_of_mousedev" was locked in another thread */
	else if (ldv_undef_int()) {
		/* NOTE Mutex "mutex_of_mousedev" was locked in another thread */
		return 1;
	}
	else {
		/* NOTE Mutex "mutex_of_mousedev" was not acquired in this or another thread */
		return 0;
	}
}

/* MODEL_FUNC Lock mutex "mutex_of_mousedev" if it was not locked before */
int ldv_mutex_trylock_mutex_of_mousedev(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_mousedev" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock try", !ldv_set_contains(LDV_MUTEXES_mutex_of_mousedev, lock));

	/* NOTE Whether mutex "mutex_of_mousedev" was locked */
	if (ldv_mutex_is_locked_mutex_of_mousedev(lock)) {
		/* NOTE Mutex "mutex_of_mousedev" was locked */
		return 0;
	}
	else {
		/* NOTE Lock mutex "mutex_of_mousedev" */
		ldv_set_add(LDV_MUTEXES_mutex_of_mousedev, lock);
		/* NOTE Successfully locked mutex "mutex_of_mousedev" */
		return 1;
	}
}

/* MODEL_FUNC Decrease counter by one and if it becomes zero check that mutex "mutex_of_mousedev" was not locked and lock it */
int ldv_atomic_dec_and_mutex_lock_mutex_of_mousedev(atomic_t *cnt, struct mutex *lock)
{
	/* NOTE Decrease counter by one */
	cnt->counter--;

	/* NOTE Whether counter becomes zero */
	if (cnt->counter) {
		/* NOTE Do not lock mutex "mutex_of_mousedev" since counter is greater than zero */
		return 0;
	}
	else {
		ldv_mutex_lock_mutex_of_mousedev(lock);
		/* NOTE Successfully locked mutex "mutex_of_mousedev" */
		return 1;
	}
}

/* MODEL_FUNC Check that mutex "mutex_of_mousedev" was locked and unlock it */
void ldv_mutex_unlock_mutex_of_mousedev(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_mousedev" must be locked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double unlock", ldv_set_contains(LDV_MUTEXES_mutex_of_mousedev, lock));
	/* NOTE Unlock mutex "mutex_of_mousedev" */
	ldv_set_remove(LDV_MUTEXES_mutex_of_mousedev, lock);
}
/* MODEL_FUNC Make all mutexes unlocked at the beginning */
void ldv_initialize(void)
{
	/* NOTE Mutex "mousedev_table_mutex" is unlocked at the beginning */
	ldv_set_init(LDV_MUTEXES_mousedev_table_mutex);
	/* NOTE Mutex "mutex_of_mousedev" is unlocked at the beginning */
	ldv_set_init(LDV_MUTEXES_mutex_of_mousedev);
}

/* MODEL_FUNC Check that all mutexes are unlocked at the end */
void ldv_check_final_state(void)
{
	/* ASSERT Mutex "mousedev_table_mutex" must be unlocked at the end */
	ldv_assert("linux:kernel:locking:mutex::one thread:locked at exit", ldv_set_is_empty(LDV_MUTEXES_mousedev_table_mutex));
	/* ASSERT Mutex "mutex_of_mousedev" must be unlocked at the end */
	ldv_assert("linux:kernel:locking:mutex::one thread:locked at exit", ldv_set_is_empty(LDV_MUTEXES_mutex_of_mousedev));
}