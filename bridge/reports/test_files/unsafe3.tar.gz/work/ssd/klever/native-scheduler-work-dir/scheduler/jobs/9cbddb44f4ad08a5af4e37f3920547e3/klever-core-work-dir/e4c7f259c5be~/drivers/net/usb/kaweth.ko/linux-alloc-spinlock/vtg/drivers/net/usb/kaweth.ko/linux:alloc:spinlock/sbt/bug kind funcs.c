/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_alloc_spinlock__nonatomic(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_alloc_spinlock__wrong_flags(int expr) {
	if (!expr)
		__VERIFIER_error();
}
