/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_block_queue__double_allocation(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_block_queue__more_initial_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_block_queue__use_before_allocation(int expr) {
	if (!expr)
		__VERIFIER_error();
}
