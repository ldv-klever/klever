#include <linux/ldv/common.h>

int my_test_func(void) {
    return 1;
}
