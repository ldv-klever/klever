
typedef struct scsi_cmnd Scsi_Cmnd;
