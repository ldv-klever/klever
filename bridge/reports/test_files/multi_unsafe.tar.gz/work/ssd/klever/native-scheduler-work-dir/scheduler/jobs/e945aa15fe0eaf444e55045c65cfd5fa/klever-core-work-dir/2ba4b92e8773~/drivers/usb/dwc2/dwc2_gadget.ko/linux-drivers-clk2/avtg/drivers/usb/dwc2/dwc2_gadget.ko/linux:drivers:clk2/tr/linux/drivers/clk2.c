/*
 * Copyright (c) 2014-2016 ISPRAS (http://www.ispras.ru)
 * Institute for System Programming of the Russian Academy of Sciences
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * ee the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <verifier/common.h>
#include <verifier/nondet.h>

struct clk;

/* NOTE Initialize counter to zero */
int ldv_counter_clk = 0;

/* MODEL_FUNC Release */
void ldv_clk_disable_clk(struct clk *clk)
{
    /* ASSERT The clk must be freed only once */
    ldv_assert("linux:drivers:clk2::less initial decrement", ldv_counter_clk == 1);
    /* NOTE Increase counter */
    ldv_counter_clk = 0;
}

/* MODEL_FUNC Reset counter */
int ldv_clk_enable_clk(void)
{
	int retval = ldv_undef_int();
	if (!retval) {
		/* NOTE Increase counter */
		ldv_counter_clk = 1;
	}
	return retval;
}
/* NOTE Initialize counter to zero */
int ldv_counter_clk_of_s3c_hsotg = 0;

/* MODEL_FUNC Release */
void ldv_clk_disable_clk_of_s3c_hsotg(struct clk *clk)
{
    /* ASSERT The clk must be freed only once */
    ldv_assert("linux:drivers:clk2::less initial decrement", ldv_counter_clk_of_s3c_hsotg == 1);
    /* NOTE Increase counter */
    ldv_counter_clk_of_s3c_hsotg = 0;
}

/* MODEL_FUNC Reset counter */
int ldv_clk_enable_clk_of_s3c_hsotg(void)
{
	int retval = ldv_undef_int();
	if (!retval) {
		/* NOTE Increase counter */
		ldv_counter_clk_of_s3c_hsotg = 1;
	}
	return retval;
}
