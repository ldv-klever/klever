/*
 * Copyright (c) 2014-2016 ISPRAS (http://www.ispras.ru)
 * Institute for System Programming of the Russian Academy of Sciences
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * ee the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <linux/errno.h>
#include <linux/types.h>
#include <linux/ldv/common.h>
#include <verifier/common.h>
#include <verifier/nondet.h>
#include <verifier/set.h>

struct mutex;

ldv_set LDV_MUTEXES_i2c_mutex_of_dvb_usb_device;

/* MODEL_FUNC Check that mutex "i2c_mutex_of_dvb_usb_device" was not locked and lock it */
void ldv_mutex_lock_i2c_mutex_of_dvb_usb_device(struct mutex *lock)
{
	/* ASSERT Mutex "i2c_mutex_of_dvb_usb_device" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock));
	/* NOTE Lock mutex "i2c_mutex_of_dvb_usb_device" */
	ldv_set_add(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock);
}

/* MODEL_FUNC Check that mutex "i2c_mutex_of_dvb_usb_device" was not locked and nondeterministically lock it */
int ldv_mutex_lock_interruptible_or_killable_i2c_mutex_of_dvb_usb_device(struct mutex *lock)
{
	/* ASSERT Mutex "i2c_mutex_of_dvb_usb_device" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock));
	/* NOTE Nondeterministically lock mutex "i2c_mutex_of_dvb_usb_device" */
	if (ldv_undef_int()) {
		/* NOTE Lock mutex "i2c_mutex_of_dvb_usb_device" */
		ldv_set_add(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock);
		/* NOTE Successfully locked mutex "i2c_mutex_of_dvb_usb_device" */
		return 0;
	}
	else {
		/* NOTE Could not lock mutex "i2c_mutex_of_dvb_usb_device" */
		return -EINTR;
	}
}

/* MODEL_FUNC Say whether mutex "i2c_mutex_of_dvb_usb_device" was locked in this or another thread  */
int ldv_mutex_is_locked_i2c_mutex_of_dvb_usb_device(struct mutex *lock)
{
	/* NOTE Whether mutex "i2c_mutex_of_dvb_usb_device" was locked in this thread */
	if (ldv_set_contains(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock)) {
		/* NOTE Mutex "i2c_mutex_of_dvb_usb_device" was locked in this thread */
		return 1;
	}
	/* NOTE Nondeterministically decide whether mutex "i2c_mutex_of_dvb_usb_device" was locked in another thread */
	else if (ldv_undef_int()) {
		/* NOTE Mutex "i2c_mutex_of_dvb_usb_device" was locked in another thread */
		return 1;
	}
	else {
		/* NOTE Mutex "i2c_mutex_of_dvb_usb_device" was not acquired in this or another thread */
		return 0;
	}
}

/* MODEL_FUNC Lock mutex "i2c_mutex_of_dvb_usb_device" if it was not locked before */
int ldv_mutex_trylock_i2c_mutex_of_dvb_usb_device(struct mutex *lock)
{
	/* ASSERT Mutex "i2c_mutex_of_dvb_usb_device" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock try", !ldv_set_contains(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock));

	/* NOTE Whether mutex "i2c_mutex_of_dvb_usb_device" was locked */
	if (ldv_mutex_is_locked_i2c_mutex_of_dvb_usb_device(lock)) {
		/* NOTE Mutex "i2c_mutex_of_dvb_usb_device" was locked */
		return 0;
	}
	else {
		/* NOTE Lock mutex "i2c_mutex_of_dvb_usb_device" */
		ldv_set_add(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock);
		/* NOTE Successfully locked mutex "i2c_mutex_of_dvb_usb_device" */
		return 1;
	}
}

/* MODEL_FUNC Decrease counter by one and if it becomes zero check that mutex "i2c_mutex_of_dvb_usb_device" was not locked and lock it */
int ldv_atomic_dec_and_mutex_lock_i2c_mutex_of_dvb_usb_device(atomic_t *cnt, struct mutex *lock)
{
	/* NOTE Decrease counter by one */
	cnt->counter--;

	/* NOTE Whether counter becomes zero */
	if (cnt->counter) {
		/* NOTE Do not lock mutex "i2c_mutex_of_dvb_usb_device" since counter is greater than zero */
		return 0;
	}
	else {
		ldv_mutex_lock_i2c_mutex_of_dvb_usb_device(lock);
		/* NOTE Successfully locked mutex "i2c_mutex_of_dvb_usb_device" */
		return 1;
	}
}

/* MODEL_FUNC Check that mutex "i2c_mutex_of_dvb_usb_device" was locked and unlock it */
void ldv_mutex_unlock_i2c_mutex_of_dvb_usb_device(struct mutex *lock)
{
	/* ASSERT Mutex "i2c_mutex_of_dvb_usb_device" must be locked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double unlock", ldv_set_contains(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock));
	/* NOTE Unlock mutex "i2c_mutex_of_dvb_usb_device" */
	ldv_set_remove(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device, lock);
}
ldv_set LDV_MUTEXES_lock;

/* MODEL_FUNC Check that mutex "lock" was not locked and lock it */
void ldv_mutex_lock_lock(struct mutex *lock)
{
	/* ASSERT Mutex "lock" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_lock, lock));
	/* NOTE Lock mutex "lock" */
	ldv_set_add(LDV_MUTEXES_lock, lock);
}

/* MODEL_FUNC Check that mutex "lock" was not locked and nondeterministically lock it */
int ldv_mutex_lock_interruptible_or_killable_lock(struct mutex *lock)
{
	/* ASSERT Mutex "lock" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_lock, lock));
	/* NOTE Nondeterministically lock mutex "lock" */
	if (ldv_undef_int()) {
		/* NOTE Lock mutex "lock" */
		ldv_set_add(LDV_MUTEXES_lock, lock);
		/* NOTE Successfully locked mutex "lock" */
		return 0;
	}
	else {
		/* NOTE Could not lock mutex "lock" */
		return -EINTR;
	}
}

/* MODEL_FUNC Say whether mutex "lock" was locked in this or another thread  */
int ldv_mutex_is_locked_lock(struct mutex *lock)
{
	/* NOTE Whether mutex "lock" was locked in this thread */
	if (ldv_set_contains(LDV_MUTEXES_lock, lock)) {
		/* NOTE Mutex "lock" was locked in this thread */
		return 1;
	}
	/* NOTE Nondeterministically decide whether mutex "lock" was locked in another thread */
	else if (ldv_undef_int()) {
		/* NOTE Mutex "lock" was locked in another thread */
		return 1;
	}
	else {
		/* NOTE Mutex "lock" was not acquired in this or another thread */
		return 0;
	}
}

/* MODEL_FUNC Lock mutex "lock" if it was not locked before */
int ldv_mutex_trylock_lock(struct mutex *lock)
{
	/* ASSERT Mutex "lock" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock try", !ldv_set_contains(LDV_MUTEXES_lock, lock));

	/* NOTE Whether mutex "lock" was locked */
	if (ldv_mutex_is_locked_lock(lock)) {
		/* NOTE Mutex "lock" was locked */
		return 0;
	}
	else {
		/* NOTE Lock mutex "lock" */
		ldv_set_add(LDV_MUTEXES_lock, lock);
		/* NOTE Successfully locked mutex "lock" */
		return 1;
	}
}

/* MODEL_FUNC Decrease counter by one and if it becomes zero check that mutex "lock" was not locked and lock it */
int ldv_atomic_dec_and_mutex_lock_lock(atomic_t *cnt, struct mutex *lock)
{
	/* NOTE Decrease counter by one */
	cnt->counter--;

	/* NOTE Whether counter becomes zero */
	if (cnt->counter) {
		/* NOTE Do not lock mutex "lock" since counter is greater than zero */
		return 0;
	}
	else {
		ldv_mutex_lock_lock(lock);
		/* NOTE Successfully locked mutex "lock" */
		return 1;
	}
}

/* MODEL_FUNC Check that mutex "lock" was locked and unlock it */
void ldv_mutex_unlock_lock(struct mutex *lock)
{
	/* ASSERT Mutex "lock" must be locked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double unlock", ldv_set_contains(LDV_MUTEXES_lock, lock));
	/* NOTE Unlock mutex "lock" */
	ldv_set_remove(LDV_MUTEXES_lock, lock);
}
ldv_set LDV_MUTEXES_mutex_of_device;

/* MODEL_FUNC Check that mutex "mutex_of_device" was not locked and lock it */
void ldv_mutex_lock_mutex_of_device(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_device" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_mutex_of_device, lock));
	/* NOTE Lock mutex "mutex_of_device" */
	ldv_set_add(LDV_MUTEXES_mutex_of_device, lock);
}

/* MODEL_FUNC Check that mutex "mutex_of_device" was not locked and nondeterministically lock it */
int ldv_mutex_lock_interruptible_or_killable_mutex_of_device(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_device" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock", !ldv_set_contains(LDV_MUTEXES_mutex_of_device, lock));
	/* NOTE Nondeterministically lock mutex "mutex_of_device" */
	if (ldv_undef_int()) {
		/* NOTE Lock mutex "mutex_of_device" */
		ldv_set_add(LDV_MUTEXES_mutex_of_device, lock);
		/* NOTE Successfully locked mutex "mutex_of_device" */
		return 0;
	}
	else {
		/* NOTE Could not lock mutex "mutex_of_device" */
		return -EINTR;
	}
}

/* MODEL_FUNC Say whether mutex "mutex_of_device" was locked in this or another thread  */
int ldv_mutex_is_locked_mutex_of_device(struct mutex *lock)
{
	/* NOTE Whether mutex "mutex_of_device" was locked in this thread */
	if (ldv_set_contains(LDV_MUTEXES_mutex_of_device, lock)) {
		/* NOTE Mutex "mutex_of_device" was locked in this thread */
		return 1;
	}
	/* NOTE Nondeterministically decide whether mutex "mutex_of_device" was locked in another thread */
	else if (ldv_undef_int()) {
		/* NOTE Mutex "mutex_of_device" was locked in another thread */
		return 1;
	}
	else {
		/* NOTE Mutex "mutex_of_device" was not acquired in this or another thread */
		return 0;
	}
}

/* MODEL_FUNC Lock mutex "mutex_of_device" if it was not locked before */
int ldv_mutex_trylock_mutex_of_device(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_device" must be unlocked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double lock try", !ldv_set_contains(LDV_MUTEXES_mutex_of_device, lock));

	/* NOTE Whether mutex "mutex_of_device" was locked */
	if (ldv_mutex_is_locked_mutex_of_device(lock)) {
		/* NOTE Mutex "mutex_of_device" was locked */
		return 0;
	}
	else {
		/* NOTE Lock mutex "mutex_of_device" */
		ldv_set_add(LDV_MUTEXES_mutex_of_device, lock);
		/* NOTE Successfully locked mutex "mutex_of_device" */
		return 1;
	}
}

/* MODEL_FUNC Decrease counter by one and if it becomes zero check that mutex "mutex_of_device" was not locked and lock it */
int ldv_atomic_dec_and_mutex_lock_mutex_of_device(atomic_t *cnt, struct mutex *lock)
{
	/* NOTE Decrease counter by one */
	cnt->counter--;

	/* NOTE Whether counter becomes zero */
	if (cnt->counter) {
		/* NOTE Do not lock mutex "mutex_of_device" since counter is greater than zero */
		return 0;
	}
	else {
		ldv_mutex_lock_mutex_of_device(lock);
		/* NOTE Successfully locked mutex "mutex_of_device" */
		return 1;
	}
}

/* MODEL_FUNC Check that mutex "mutex_of_device" was locked and unlock it */
void ldv_mutex_unlock_mutex_of_device(struct mutex *lock)
{
	/* ASSERT Mutex "mutex_of_device" must be locked */
	ldv_assert("linux:kernel:locking:mutex::one thread:double unlock", ldv_set_contains(LDV_MUTEXES_mutex_of_device, lock));
	/* NOTE Unlock mutex "mutex_of_device" */
	ldv_set_remove(LDV_MUTEXES_mutex_of_device, lock);
}
/* MODEL_FUNC Make all mutexes unlocked at the beginning */
void ldv_initialize(void)
{
	/* NOTE Mutex "i2c_mutex_of_dvb_usb_device" is unlocked at the beginning */
	ldv_set_init(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device);
	/* NOTE Mutex "lock" is unlocked at the beginning */
	ldv_set_init(LDV_MUTEXES_lock);
	/* NOTE Mutex "mutex_of_device" is unlocked at the beginning */
	ldv_set_init(LDV_MUTEXES_mutex_of_device);
}

/* MODEL_FUNC Check that all mutexes are unlocked at the end */
void ldv_check_final_state(void)
{
	/* ASSERT Mutex "i2c_mutex_of_dvb_usb_device" must be unlocked at the end */
	ldv_assert("linux:kernel:locking:mutex::one thread:locked at exit", ldv_set_is_empty(LDV_MUTEXES_i2c_mutex_of_dvb_usb_device));
	/* ASSERT Mutex "lock" must be unlocked at the end */
	ldv_assert("linux:kernel:locking:mutex::one thread:locked at exit", ldv_set_is_empty(LDV_MUTEXES_lock));
	/* ASSERT Mutex "mutex_of_device" must be unlocked at the end */
	ldv_assert("linux:kernel:locking:mutex::one thread:locked at exit", ldv_set_is_empty(LDV_MUTEXES_mutex_of_device));
}