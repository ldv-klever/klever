/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_kernel_locking_mutex__one_thread_double_lock(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_mutex__one_thread_double_lock_try(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_mutex__one_thread_double_unlock(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_mutex__one_thread_locked_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
