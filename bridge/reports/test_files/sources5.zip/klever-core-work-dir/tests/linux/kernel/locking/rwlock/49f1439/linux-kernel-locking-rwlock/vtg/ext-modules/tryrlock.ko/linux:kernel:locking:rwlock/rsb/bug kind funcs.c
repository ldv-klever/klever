/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_kernel_locking_rwlock__double_write_lock(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_rwlock__double_write_unlock(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_rwlock__more_read_unlocks(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_rwlock__read_lock_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_rwlock__read_lock_on_write_lock(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_kernel_locking_rwlock__write_lock_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
