/*
 * Copyright (c) 2014-2016 ISPRAS (http://www.ispras.ru)
 * Institute for System Programming of the Russian Academy of Sciences
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * ee the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <linux/ldv/common.h>
#include <verifier/common.h>
#include <verifier/nondet.h>

static int ldv_spin__xmit_lock_of_netdev_queue = 1;

/* MODEL_FUNC Check that spinlock "_xmit_lock_of_netdev_queue" was not locked and lock it */
void ldv_spin_lock__xmit_lock_of_netdev_queue(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Lock spinlock "_xmit_lock_of_netdev_queue" */
	ldv_spin__xmit_lock_of_netdev_queue = 2;
}

/* MODEL_FUNC Check that spinlock "_xmit_lock_of_netdev_queue" was locked and unlock it */
void ldv_spin_unlock__xmit_lock_of_netdev_queue(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin__xmit_lock_of_netdev_queue == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 2);
	/* NOTE Unlock spinlock "_xmit_lock_of_netdev_queue" */
	ldv_spin__xmit_lock_of_netdev_queue = 1;
}

/* MODEL_FUNC Check that spinlock "_xmit_lock_of_netdev_queue" was not locked and nondeterministically lock it */
int ldv_spin_trylock__xmit_lock_of_netdev_queue(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "_xmit_lock_of_netdev_queue" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "_xmit_lock_of_netdev_queue" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "_xmit_lock_of_netdev_queue" */
		ldv_spin__xmit_lock_of_netdev_queue = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "_xmit_lock_of_netdev_queue" and wait until it will be unlocked */
void ldv_spin_unlock_wait__xmit_lock_of_netdev_queue(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);
}

/* MODEL_FUNC Check whether spinlock "_xmit_lock_of_netdev_queue" was locked */
int ldv_spin_is_locked__xmit_lock_of_netdev_queue(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "_xmit_lock_of_netdev_queue" was locked */
	if(ldv_spin__xmit_lock_of_netdev_queue == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "_xmit_lock_of_netdev_queue" was not locked */
int ldv_spin_can_lock__xmit_lock_of_netdev_queue(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked__xmit_lock_of_netdev_queue();
}

/* MODEL_FUNC Check whether spinlock "_xmit_lock_of_netdev_queue" is contended */
int ldv_spin_is_contended__xmit_lock_of_netdev_queue(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "_xmit_lock_of_netdev_queue" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "_xmit_lock_of_netdev_queue" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock__xmit_lock_of_netdev_queue(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin__xmit_lock_of_netdev_queue == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "_xmit_lock_of_netdev_queue" */
		ldv_spin__xmit_lock_of_netdev_queue = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "_xmit_lock_of_netdev_queue" */
	return 0;
}
static int ldv_spin_addr_list_lock_of_net_device = 1;

/* MODEL_FUNC Check that spinlock "addr_list_lock_of_net_device" was not locked and lock it */
void ldv_spin_lock_addr_list_lock_of_net_device(void)
{
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Lock spinlock "addr_list_lock_of_net_device" */
	ldv_spin_addr_list_lock_of_net_device = 2;
}

/* MODEL_FUNC Check that spinlock "addr_list_lock_of_net_device" was locked and unlock it */
void ldv_spin_unlock_addr_list_lock_of_net_device(void)
{
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_addr_list_lock_of_net_device == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 2);
	/* NOTE Unlock spinlock "addr_list_lock_of_net_device" */
	ldv_spin_addr_list_lock_of_net_device = 1;
}

/* MODEL_FUNC Check that spinlock "addr_list_lock_of_net_device" was not locked and nondeterministically lock it */
int ldv_spin_trylock_addr_list_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "addr_list_lock_of_net_device" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "addr_list_lock_of_net_device" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "addr_list_lock_of_net_device" */
		ldv_spin_addr_list_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "addr_list_lock_of_net_device" and wait until it will be unlocked */
void ldv_spin_unlock_wait_addr_list_lock_of_net_device(void)
{
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);
}

/* MODEL_FUNC Check whether spinlock "addr_list_lock_of_net_device" was locked */
int ldv_spin_is_locked_addr_list_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "addr_list_lock_of_net_device" was locked */
	if(ldv_spin_addr_list_lock_of_net_device == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "addr_list_lock_of_net_device" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "addr_list_lock_of_net_device" was not locked */
int ldv_spin_can_lock_addr_list_lock_of_net_device(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_addr_list_lock_of_net_device();
}

/* MODEL_FUNC Check whether spinlock "addr_list_lock_of_net_device" is contended */
int ldv_spin_is_contended_addr_list_lock_of_net_device(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "addr_list_lock_of_net_device" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "addr_list_lock_of_net_device" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_addr_list_lock_of_net_device(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_addr_list_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_addr_list_lock_of_net_device == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "addr_list_lock_of_net_device" */
		ldv_spin_addr_list_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "addr_list_lock_of_net_device" */
	return 0;
}
static int ldv_spin_alloc_lock_of_task_struct = 1;

/* MODEL_FUNC Check that spinlock "alloc_lock_of_task_struct" was not locked and lock it */
void ldv_spin_lock_alloc_lock_of_task_struct(void)
{
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Lock spinlock "alloc_lock_of_task_struct" */
	ldv_spin_alloc_lock_of_task_struct = 2;
}

/* MODEL_FUNC Check that spinlock "alloc_lock_of_task_struct" was locked and unlock it */
void ldv_spin_unlock_alloc_lock_of_task_struct(void)
{
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_alloc_lock_of_task_struct == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 2);
	/* NOTE Unlock spinlock "alloc_lock_of_task_struct" */
	ldv_spin_alloc_lock_of_task_struct = 1;
}

/* MODEL_FUNC Check that spinlock "alloc_lock_of_task_struct" was not locked and nondeterministically lock it */
int ldv_spin_trylock_alloc_lock_of_task_struct(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "alloc_lock_of_task_struct" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "alloc_lock_of_task_struct" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "alloc_lock_of_task_struct" */
		ldv_spin_alloc_lock_of_task_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "alloc_lock_of_task_struct" and wait until it will be unlocked */
void ldv_spin_unlock_wait_alloc_lock_of_task_struct(void)
{
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);
}

/* MODEL_FUNC Check whether spinlock "alloc_lock_of_task_struct" was locked */
int ldv_spin_is_locked_alloc_lock_of_task_struct(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "alloc_lock_of_task_struct" was locked */
	if(ldv_spin_alloc_lock_of_task_struct == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "alloc_lock_of_task_struct" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "alloc_lock_of_task_struct" was not locked */
int ldv_spin_can_lock_alloc_lock_of_task_struct(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_alloc_lock_of_task_struct();
}

/* MODEL_FUNC Check whether spinlock "alloc_lock_of_task_struct" is contended */
int ldv_spin_is_contended_alloc_lock_of_task_struct(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "alloc_lock_of_task_struct" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "alloc_lock_of_task_struct" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_alloc_lock_of_task_struct(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_alloc_lock_of_task_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_alloc_lock_of_task_struct == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "alloc_lock_of_task_struct" */
		ldv_spin_alloc_lock_of_task_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "alloc_lock_of_task_struct" */
	return 0;
}
static int ldv_spin_bc_lock = 1;

/* MODEL_FUNC Check that spinlock "bc_lock" was not locked and lock it */
void ldv_spin_lock_bc_lock(void)
{
	/* ASSERT Spinlock "bc_lock" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_bc_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_bc_lock == 1);
	/* NOTE Lock spinlock "bc_lock" */
	ldv_spin_bc_lock = 2;
}

/* MODEL_FUNC Check that spinlock "bc_lock" was locked and unlock it */
void ldv_spin_unlock_bc_lock(void)
{
	/* ASSERT Spinlock "bc_lock" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_bc_lock == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_bc_lock == 2);
	/* NOTE Unlock spinlock "bc_lock" */
	ldv_spin_bc_lock = 1;
}

/* MODEL_FUNC Check that spinlock "bc_lock" was not locked and nondeterministically lock it */
int ldv_spin_trylock_bc_lock(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "bc_lock" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_bc_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_bc_lock == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "bc_lock" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "bc_lock" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "bc_lock" */
		ldv_spin_bc_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "bc_lock" and wait until it will be unlocked */
void ldv_spin_unlock_wait_bc_lock(void)
{
	/* ASSERT Spinlock "bc_lock" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_bc_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_bc_lock == 1);
}

/* MODEL_FUNC Check whether spinlock "bc_lock" was locked */
int ldv_spin_is_locked_bc_lock(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "bc_lock" was locked */
	if(ldv_spin_bc_lock == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "bc_lock" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "bc_lock" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "bc_lock" was not locked */
int ldv_spin_can_lock_bc_lock(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_bc_lock();
}

/* MODEL_FUNC Check whether spinlock "bc_lock" is contended */
int ldv_spin_is_contended_bc_lock(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "bc_lock" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "bc_lock" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "bc_lock" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "bc_lock" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_bc_lock(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "bc_lock" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_bc_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_bc_lock == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "bc_lock" */
		ldv_spin_bc_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "bc_lock" */
	return 0;
}
static int ldv_spin_i_lock_of_inode = 1;

/* MODEL_FUNC Check that spinlock "i_lock_of_inode" was not locked and lock it */
void ldv_spin_lock_i_lock_of_inode(void)
{
	/* ASSERT Spinlock "i_lock_of_inode" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);
	/* NOTE Lock spinlock "i_lock_of_inode" */
	ldv_spin_i_lock_of_inode = 2;
}

/* MODEL_FUNC Check that spinlock "i_lock_of_inode" was locked and unlock it */
void ldv_spin_unlock_i_lock_of_inode(void)
{
	/* ASSERT Spinlock "i_lock_of_inode" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_i_lock_of_inode == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 2);
	/* NOTE Unlock spinlock "i_lock_of_inode" */
	ldv_spin_i_lock_of_inode = 1;
}

/* MODEL_FUNC Check that spinlock "i_lock_of_inode" was not locked and nondeterministically lock it */
int ldv_spin_trylock_i_lock_of_inode(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "i_lock_of_inode" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "i_lock_of_inode" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "i_lock_of_inode" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "i_lock_of_inode" */
		ldv_spin_i_lock_of_inode = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "i_lock_of_inode" and wait until it will be unlocked */
void ldv_spin_unlock_wait_i_lock_of_inode(void)
{
	/* ASSERT Spinlock "i_lock_of_inode" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);
}

/* MODEL_FUNC Check whether spinlock "i_lock_of_inode" was locked */
int ldv_spin_is_locked_i_lock_of_inode(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "i_lock_of_inode" was locked */
	if(ldv_spin_i_lock_of_inode == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "i_lock_of_inode" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "i_lock_of_inode" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "i_lock_of_inode" was not locked */
int ldv_spin_can_lock_i_lock_of_inode(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_i_lock_of_inode();
}

/* MODEL_FUNC Check whether spinlock "i_lock_of_inode" is contended */
int ldv_spin_is_contended_i_lock_of_inode(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "i_lock_of_inode" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "i_lock_of_inode" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "i_lock_of_inode" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "i_lock_of_inode" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_i_lock_of_inode(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "i_lock_of_inode" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_i_lock_of_inode == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_i_lock_of_inode == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "i_lock_of_inode" */
		ldv_spin_i_lock_of_inode = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "i_lock_of_inode" */
	return 0;
}
static int ldv_spin_idr_lock_of_tipc_server = 1;

/* MODEL_FUNC Check that spinlock "idr_lock_of_tipc_server" was not locked and lock it */
void ldv_spin_lock_idr_lock_of_tipc_server(void)
{
	/* ASSERT Spinlock "idr_lock_of_tipc_server" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_idr_lock_of_tipc_server == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_idr_lock_of_tipc_server == 1);
	/* NOTE Lock spinlock "idr_lock_of_tipc_server" */
	ldv_spin_idr_lock_of_tipc_server = 2;
}

/* MODEL_FUNC Check that spinlock "idr_lock_of_tipc_server" was locked and unlock it */
void ldv_spin_unlock_idr_lock_of_tipc_server(void)
{
	/* ASSERT Spinlock "idr_lock_of_tipc_server" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_idr_lock_of_tipc_server == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_idr_lock_of_tipc_server == 2);
	/* NOTE Unlock spinlock "idr_lock_of_tipc_server" */
	ldv_spin_idr_lock_of_tipc_server = 1;
}

/* MODEL_FUNC Check that spinlock "idr_lock_of_tipc_server" was not locked and nondeterministically lock it */
int ldv_spin_trylock_idr_lock_of_tipc_server(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "idr_lock_of_tipc_server" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_idr_lock_of_tipc_server == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_idr_lock_of_tipc_server == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "idr_lock_of_tipc_server" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "idr_lock_of_tipc_server" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "idr_lock_of_tipc_server" */
		ldv_spin_idr_lock_of_tipc_server = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "idr_lock_of_tipc_server" and wait until it will be unlocked */
void ldv_spin_unlock_wait_idr_lock_of_tipc_server(void)
{
	/* ASSERT Spinlock "idr_lock_of_tipc_server" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_idr_lock_of_tipc_server == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_idr_lock_of_tipc_server == 1);
}

/* MODEL_FUNC Check whether spinlock "idr_lock_of_tipc_server" was locked */
int ldv_spin_is_locked_idr_lock_of_tipc_server(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "idr_lock_of_tipc_server" was locked */
	if(ldv_spin_idr_lock_of_tipc_server == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "idr_lock_of_tipc_server" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "idr_lock_of_tipc_server" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "idr_lock_of_tipc_server" was not locked */
int ldv_spin_can_lock_idr_lock_of_tipc_server(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_idr_lock_of_tipc_server();
}

/* MODEL_FUNC Check whether spinlock "idr_lock_of_tipc_server" is contended */
int ldv_spin_is_contended_idr_lock_of_tipc_server(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "idr_lock_of_tipc_server" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "idr_lock_of_tipc_server" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "idr_lock_of_tipc_server" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "idr_lock_of_tipc_server" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_idr_lock_of_tipc_server(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "idr_lock_of_tipc_server" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_idr_lock_of_tipc_server == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_idr_lock_of_tipc_server == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "idr_lock_of_tipc_server" */
		ldv_spin_idr_lock_of_tipc_server = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "idr_lock_of_tipc_server" */
	return 0;
}
static int ldv_spin_lock = 1;

/* MODEL_FUNC Check that spinlock "lock" was not locked and lock it */
void ldv_spin_lock_lock(void)
{
	/* ASSERT Spinlock "lock" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock == 1);
	/* NOTE Lock spinlock "lock" */
	ldv_spin_lock = 2;
}

/* MODEL_FUNC Check that spinlock "lock" was locked and unlock it */
void ldv_spin_unlock_lock(void)
{
	/* ASSERT Spinlock "lock" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock == 2);
	/* NOTE Unlock spinlock "lock" */
	ldv_spin_lock = 1;
}

/* MODEL_FUNC Check that spinlock "lock" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock" */
		ldv_spin_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock(void)
{
	/* ASSERT Spinlock "lock" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock == 1);
}

/* MODEL_FUNC Check whether spinlock "lock" was locked */
int ldv_spin_is_locked_lock(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock" was locked */
	if(ldv_spin_lock == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock" was not locked */
int ldv_spin_can_lock_lock(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock();
}

/* MODEL_FUNC Check whether spinlock "lock" is contended */
int ldv_spin_is_contended_lock(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock" */
		ldv_spin_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock" */
	return 0;
}
static int ldv_spin_lock_of_NOT_ARG_SIGN = 1;

/* MODEL_FUNC Check that spinlock "lock_of_NOT_ARG_SIGN" was not locked and lock it */
void ldv_spin_lock_lock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Lock spinlock "lock_of_NOT_ARG_SIGN" */
	ldv_spin_lock_of_NOT_ARG_SIGN = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_NOT_ARG_SIGN" was locked and unlock it */
void ldv_spin_unlock_lock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_NOT_ARG_SIGN == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 2);
	/* NOTE Unlock spinlock "lock_of_NOT_ARG_SIGN" */
	ldv_spin_lock_of_NOT_ARG_SIGN = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_NOT_ARG_SIGN" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_NOT_ARG_SIGN(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_NOT_ARG_SIGN" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_NOT_ARG_SIGN" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_NOT_ARG_SIGN" */
		ldv_spin_lock_of_NOT_ARG_SIGN = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_NOT_ARG_SIGN" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_NOT_ARG_SIGN" was locked */
int ldv_spin_is_locked_lock_of_NOT_ARG_SIGN(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_NOT_ARG_SIGN" was locked */
	if(ldv_spin_lock_of_NOT_ARG_SIGN == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_NOT_ARG_SIGN" was not locked */
int ldv_spin_can_lock_lock_of_NOT_ARG_SIGN(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_NOT_ARG_SIGN();
}

/* MODEL_FUNC Check whether spinlock "lock_of_NOT_ARG_SIGN" is contended */
int ldv_spin_is_contended_lock_of_NOT_ARG_SIGN(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_NOT_ARG_SIGN" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_NOT_ARG_SIGN" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_NOT_ARG_SIGN(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_NOT_ARG_SIGN == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_NOT_ARG_SIGN" */
		ldv_spin_lock_of_NOT_ARG_SIGN = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_NOT_ARG_SIGN" */
	return 0;
}
static int ldv_spin_lock_of_name_seq = 1;

/* MODEL_FUNC Check that spinlock "lock_of_name_seq" was not locked and lock it */
void ldv_spin_lock_lock_of_name_seq(void)
{
	/* ASSERT Spinlock "lock_of_name_seq" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_name_seq == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_name_seq == 1);
	/* NOTE Lock spinlock "lock_of_name_seq" */
	ldv_spin_lock_of_name_seq = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_name_seq" was locked and unlock it */
void ldv_spin_unlock_lock_of_name_seq(void)
{
	/* ASSERT Spinlock "lock_of_name_seq" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_name_seq == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_name_seq == 2);
	/* NOTE Unlock spinlock "lock_of_name_seq" */
	ldv_spin_lock_of_name_seq = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_name_seq" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_name_seq(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_name_seq" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_name_seq == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_name_seq == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_name_seq" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_name_seq" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_name_seq" */
		ldv_spin_lock_of_name_seq = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_name_seq" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_name_seq(void)
{
	/* ASSERT Spinlock "lock_of_name_seq" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_name_seq == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_name_seq == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_name_seq" was locked */
int ldv_spin_is_locked_lock_of_name_seq(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_name_seq" was locked */
	if(ldv_spin_lock_of_name_seq == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_name_seq" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_name_seq" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_name_seq" was not locked */
int ldv_spin_can_lock_lock_of_name_seq(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_name_seq();
}

/* MODEL_FUNC Check whether spinlock "lock_of_name_seq" is contended */
int ldv_spin_is_contended_lock_of_name_seq(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_name_seq" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_name_seq" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_name_seq" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_name_seq" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_name_seq(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_name_seq" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_name_seq == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_name_seq == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_name_seq" */
		ldv_spin_lock_of_name_seq = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_name_seq" */
	return 0;
}
static int ldv_spin_lock_of_reference = 1;

/* MODEL_FUNC Check that spinlock "lock_of_reference" was not locked and lock it */
void ldv_spin_lock_lock_of_reference(void)
{
	/* ASSERT Spinlock "lock_of_reference" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_reference == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_reference == 1);
	/* NOTE Lock spinlock "lock_of_reference" */
	ldv_spin_lock_of_reference = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_reference" was locked and unlock it */
void ldv_spin_unlock_lock_of_reference(void)
{
	/* ASSERT Spinlock "lock_of_reference" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_reference == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_reference == 2);
	/* NOTE Unlock spinlock "lock_of_reference" */
	ldv_spin_lock_of_reference = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_reference" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_reference(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_reference" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_reference == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_reference == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_reference" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_reference" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_reference" */
		ldv_spin_lock_of_reference = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_reference" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_reference(void)
{
	/* ASSERT Spinlock "lock_of_reference" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_reference == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_reference == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_reference" was locked */
int ldv_spin_is_locked_lock_of_reference(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_reference" was locked */
	if(ldv_spin_lock_of_reference == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_reference" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_reference" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_reference" was not locked */
int ldv_spin_can_lock_lock_of_reference(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_reference();
}

/* MODEL_FUNC Check whether spinlock "lock_of_reference" is contended */
int ldv_spin_is_contended_lock_of_reference(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_reference" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_reference" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_reference" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_reference" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_reference(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_reference" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_reference == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_reference == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_reference" */
		ldv_spin_lock_of_reference = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_reference" */
	return 0;
}
static int ldv_spin_lock_of_res_counter = 1;

/* MODEL_FUNC Check that spinlock "lock_of_res_counter" was not locked and lock it */
void ldv_spin_lock_lock_of_res_counter(void)
{
	/* ASSERT Spinlock "lock_of_res_counter" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_res_counter == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_res_counter == 1);
	/* NOTE Lock spinlock "lock_of_res_counter" */
	ldv_spin_lock_of_res_counter = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_res_counter" was locked and unlock it */
void ldv_spin_unlock_lock_of_res_counter(void)
{
	/* ASSERT Spinlock "lock_of_res_counter" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_res_counter == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_res_counter == 2);
	/* NOTE Unlock spinlock "lock_of_res_counter" */
	ldv_spin_lock_of_res_counter = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_res_counter" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_res_counter(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_res_counter" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_res_counter == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_res_counter == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_res_counter" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_res_counter" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_res_counter" */
		ldv_spin_lock_of_res_counter = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_res_counter" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_res_counter(void)
{
	/* ASSERT Spinlock "lock_of_res_counter" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_res_counter == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_res_counter == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_res_counter" was locked */
int ldv_spin_is_locked_lock_of_res_counter(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_res_counter" was locked */
	if(ldv_spin_lock_of_res_counter == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_res_counter" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_res_counter" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_res_counter" was not locked */
int ldv_spin_can_lock_lock_of_res_counter(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_res_counter();
}

/* MODEL_FUNC Check whether spinlock "lock_of_res_counter" is contended */
int ldv_spin_is_contended_lock_of_res_counter(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_res_counter" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_res_counter" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_res_counter" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_res_counter" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_res_counter(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_res_counter" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_res_counter == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_res_counter == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_res_counter" */
		ldv_spin_lock_of_res_counter = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_res_counter" */
	return 0;
}
static int ldv_spin_lock_of_tipc_bearer = 1;

/* MODEL_FUNC Check that spinlock "lock_of_tipc_bearer" was not locked and lock it */
void ldv_spin_lock_lock_of_tipc_bearer(void)
{
	/* ASSERT Spinlock "lock_of_tipc_bearer" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_tipc_bearer == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_bearer == 1);
	/* NOTE Lock spinlock "lock_of_tipc_bearer" */
	ldv_spin_lock_of_tipc_bearer = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_bearer" was locked and unlock it */
void ldv_spin_unlock_lock_of_tipc_bearer(void)
{
	/* ASSERT Spinlock "lock_of_tipc_bearer" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_tipc_bearer == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_bearer == 2);
	/* NOTE Unlock spinlock "lock_of_tipc_bearer" */
	ldv_spin_lock_of_tipc_bearer = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_bearer" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_tipc_bearer(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_tipc_bearer" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_bearer == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_bearer == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_tipc_bearer" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_bearer" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_tipc_bearer" */
		ldv_spin_lock_of_tipc_bearer = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_tipc_bearer" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_tipc_bearer(void)
{
	/* ASSERT Spinlock "lock_of_tipc_bearer" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_bearer == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_bearer == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_bearer" was locked */
int ldv_spin_is_locked_lock_of_tipc_bearer(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_bearer" was locked */
	if(ldv_spin_lock_of_tipc_bearer == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_bearer" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_bearer" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_bearer" was not locked */
int ldv_spin_can_lock_lock_of_tipc_bearer(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_tipc_bearer();
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_bearer" is contended */
int ldv_spin_is_contended_lock_of_tipc_bearer(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_bearer" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_tipc_bearer" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_bearer" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_tipc_bearer" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_tipc_bearer(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_tipc_bearer" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_bearer == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_bearer == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_tipc_bearer" */
		ldv_spin_lock_of_tipc_bearer = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_tipc_bearer" */
	return 0;
}
static int ldv_spin_lock_of_tipc_node = 1;

/* MODEL_FUNC Check that spinlock "lock_of_tipc_node" was not locked and lock it */
void ldv_spin_lock_lock_of_tipc_node(void)
{
	/* ASSERT Spinlock "lock_of_tipc_node" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_tipc_node == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_node == 1);
	/* NOTE Lock spinlock "lock_of_tipc_node" */
	ldv_spin_lock_of_tipc_node = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_node" was locked and unlock it */
void ldv_spin_unlock_lock_of_tipc_node(void)
{
	/* ASSERT Spinlock "lock_of_tipc_node" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_tipc_node == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_node == 2);
	/* NOTE Unlock spinlock "lock_of_tipc_node" */
	ldv_spin_lock_of_tipc_node = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_node" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_tipc_node(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_tipc_node" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_node == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_node == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_tipc_node" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_node" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_tipc_node" */
		ldv_spin_lock_of_tipc_node = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_tipc_node" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_tipc_node(void)
{
	/* ASSERT Spinlock "lock_of_tipc_node" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_node == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_node == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_node" was locked */
int ldv_spin_is_locked_lock_of_tipc_node(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_node" was locked */
	if(ldv_spin_lock_of_tipc_node == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_node" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_node" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_node" was not locked */
int ldv_spin_can_lock_lock_of_tipc_node(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_tipc_node();
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_node" is contended */
int ldv_spin_is_contended_lock_of_tipc_node(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_node" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_tipc_node" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_node" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_tipc_node" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_tipc_node(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_tipc_node" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_node == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_node == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_tipc_node" */
		ldv_spin_lock_of_tipc_node = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_tipc_node" */
	return 0;
}
static int ldv_spin_lock_of_tipc_port = 1;

/* MODEL_FUNC Check that spinlock "lock_of_tipc_port" was not locked and lock it */
void ldv_spin_lock_lock_of_tipc_port(void)
{
	/* ASSERT Spinlock "lock_of_tipc_port" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_tipc_port == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_port == 1);
	/* NOTE Lock spinlock "lock_of_tipc_port" */
	ldv_spin_lock_of_tipc_port = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_port" was locked and unlock it */
void ldv_spin_unlock_lock_of_tipc_port(void)
{
	/* ASSERT Spinlock "lock_of_tipc_port" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_tipc_port == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_port == 2);
	/* NOTE Unlock spinlock "lock_of_tipc_port" */
	ldv_spin_lock_of_tipc_port = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_port" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_tipc_port(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_tipc_port" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_port == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_port == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_tipc_port" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_port" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_tipc_port" */
		ldv_spin_lock_of_tipc_port = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_tipc_port" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_tipc_port(void)
{
	/* ASSERT Spinlock "lock_of_tipc_port" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_port == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_port == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_port" was locked */
int ldv_spin_is_locked_lock_of_tipc_port(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_port" was locked */
	if(ldv_spin_lock_of_tipc_port == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_port" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_port" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_port" was not locked */
int ldv_spin_can_lock_lock_of_tipc_port(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_tipc_port();
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_port" is contended */
int ldv_spin_is_contended_lock_of_tipc_port(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_port" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_tipc_port" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_port" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_tipc_port" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_tipc_port(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_tipc_port" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_port == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_port == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_tipc_port" */
		ldv_spin_lock_of_tipc_port = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_tipc_port" */
	return 0;
}
static int ldv_spin_lock_of_tipc_subscriber = 1;

/* MODEL_FUNC Check that spinlock "lock_of_tipc_subscriber" was not locked and lock it */
void ldv_spin_lock_lock_of_tipc_subscriber(void)
{
	/* ASSERT Spinlock "lock_of_tipc_subscriber" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lock_of_tipc_subscriber == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_subscriber == 1);
	/* NOTE Lock spinlock "lock_of_tipc_subscriber" */
	ldv_spin_lock_of_tipc_subscriber = 2;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_subscriber" was locked and unlock it */
void ldv_spin_unlock_lock_of_tipc_subscriber(void)
{
	/* ASSERT Spinlock "lock_of_tipc_subscriber" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lock_of_tipc_subscriber == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_subscriber == 2);
	/* NOTE Unlock spinlock "lock_of_tipc_subscriber" */
	ldv_spin_lock_of_tipc_subscriber = 1;
}

/* MODEL_FUNC Check that spinlock "lock_of_tipc_subscriber" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lock_of_tipc_subscriber(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lock_of_tipc_subscriber" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_subscriber == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_subscriber == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lock_of_tipc_subscriber" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_subscriber" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lock_of_tipc_subscriber" */
		ldv_spin_lock_of_tipc_subscriber = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lock_of_tipc_subscriber" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lock_of_tipc_subscriber(void)
{
	/* ASSERT Spinlock "lock_of_tipc_subscriber" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_subscriber == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_subscriber == 1);
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_subscriber" was locked */
int ldv_spin_is_locked_lock_of_tipc_subscriber(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_subscriber" was locked */
	if(ldv_spin_lock_of_tipc_subscriber == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lock_of_tipc_subscriber" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_subscriber" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_subscriber" was not locked */
int ldv_spin_can_lock_lock_of_tipc_subscriber(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lock_of_tipc_subscriber();
}

/* MODEL_FUNC Check whether spinlock "lock_of_tipc_subscriber" is contended */
int ldv_spin_is_contended_lock_of_tipc_subscriber(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_subscriber" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lock_of_tipc_subscriber" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lock_of_tipc_subscriber" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lock_of_tipc_subscriber" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lock_of_tipc_subscriber(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lock_of_tipc_subscriber" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lock_of_tipc_subscriber == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lock_of_tipc_subscriber == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lock_of_tipc_subscriber" */
		ldv_spin_lock_of_tipc_subscriber = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lock_of_tipc_subscriber" */
	return 0;
}
static int ldv_spin_lru_lock_of_netns_frags = 1;

/* MODEL_FUNC Check that spinlock "lru_lock_of_netns_frags" was not locked and lock it */
void ldv_spin_lock_lru_lock_of_netns_frags(void)
{
	/* ASSERT Spinlock "lru_lock_of_netns_frags" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_lru_lock_of_netns_frags == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lru_lock_of_netns_frags == 1);
	/* NOTE Lock spinlock "lru_lock_of_netns_frags" */
	ldv_spin_lru_lock_of_netns_frags = 2;
}

/* MODEL_FUNC Check that spinlock "lru_lock_of_netns_frags" was locked and unlock it */
void ldv_spin_unlock_lru_lock_of_netns_frags(void)
{
	/* ASSERT Spinlock "lru_lock_of_netns_frags" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_lru_lock_of_netns_frags == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lru_lock_of_netns_frags == 2);
	/* NOTE Unlock spinlock "lru_lock_of_netns_frags" */
	ldv_spin_lru_lock_of_netns_frags = 1;
}

/* MODEL_FUNC Check that spinlock "lru_lock_of_netns_frags" was not locked and nondeterministically lock it */
int ldv_spin_trylock_lru_lock_of_netns_frags(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "lru_lock_of_netns_frags" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lru_lock_of_netns_frags == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lru_lock_of_netns_frags == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "lru_lock_of_netns_frags" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lru_lock_of_netns_frags" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "lru_lock_of_netns_frags" */
		ldv_spin_lru_lock_of_netns_frags = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "lru_lock_of_netns_frags" and wait until it will be unlocked */
void ldv_spin_unlock_wait_lru_lock_of_netns_frags(void)
{
	/* ASSERT Spinlock "lru_lock_of_netns_frags" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lru_lock_of_netns_frags == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lru_lock_of_netns_frags == 1);
}

/* MODEL_FUNC Check whether spinlock "lru_lock_of_netns_frags" was locked */
int ldv_spin_is_locked_lru_lock_of_netns_frags(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lru_lock_of_netns_frags" was locked */
	if(ldv_spin_lru_lock_of_netns_frags == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "lru_lock_of_netns_frags" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "lru_lock_of_netns_frags" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "lru_lock_of_netns_frags" was not locked */
int ldv_spin_can_lock_lru_lock_of_netns_frags(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_lru_lock_of_netns_frags();
}

/* MODEL_FUNC Check whether spinlock "lru_lock_of_netns_frags" is contended */
int ldv_spin_is_contended_lru_lock_of_netns_frags(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "lru_lock_of_netns_frags" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "lru_lock_of_netns_frags" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "lru_lock_of_netns_frags" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "lru_lock_of_netns_frags" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_lru_lock_of_netns_frags(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "lru_lock_of_netns_frags" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_lru_lock_of_netns_frags == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_lru_lock_of_netns_frags == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "lru_lock_of_netns_frags" */
		ldv_spin_lru_lock_of_netns_frags = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "lru_lock_of_netns_frags" */
	return 0;
}
static int ldv_spin_node_create_lock = 1;

/* MODEL_FUNC Check that spinlock "node_create_lock" was not locked and lock it */
void ldv_spin_lock_node_create_lock(void)
{
	/* ASSERT Spinlock "node_create_lock" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_node_create_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_create_lock == 1);
	/* NOTE Lock spinlock "node_create_lock" */
	ldv_spin_node_create_lock = 2;
}

/* MODEL_FUNC Check that spinlock "node_create_lock" was locked and unlock it */
void ldv_spin_unlock_node_create_lock(void)
{
	/* ASSERT Spinlock "node_create_lock" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_node_create_lock == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_create_lock == 2);
	/* NOTE Unlock spinlock "node_create_lock" */
	ldv_spin_node_create_lock = 1;
}

/* MODEL_FUNC Check that spinlock "node_create_lock" was not locked and nondeterministically lock it */
int ldv_spin_trylock_node_create_lock(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "node_create_lock" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_create_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_create_lock == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "node_create_lock" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "node_create_lock" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "node_create_lock" */
		ldv_spin_node_create_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "node_create_lock" and wait until it will be unlocked */
void ldv_spin_unlock_wait_node_create_lock(void)
{
	/* ASSERT Spinlock "node_create_lock" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_create_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_create_lock == 1);
}

/* MODEL_FUNC Check whether spinlock "node_create_lock" was locked */
int ldv_spin_is_locked_node_create_lock(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "node_create_lock" was locked */
	if(ldv_spin_node_create_lock == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "node_create_lock" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "node_create_lock" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "node_create_lock" was not locked */
int ldv_spin_can_lock_node_create_lock(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_node_create_lock();
}

/* MODEL_FUNC Check whether spinlock "node_create_lock" is contended */
int ldv_spin_is_contended_node_create_lock(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "node_create_lock" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "node_create_lock" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "node_create_lock" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "node_create_lock" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_node_create_lock(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "node_create_lock" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_create_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_create_lock == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "node_create_lock" */
		ldv_spin_node_create_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "node_create_lock" */
	return 0;
}
static int ldv_spin_node_size_lock_of_pglist_data = 1;

/* MODEL_FUNC Check that spinlock "node_size_lock_of_pglist_data" was not locked and lock it */
void ldv_spin_lock_node_size_lock_of_pglist_data(void)
{
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Lock spinlock "node_size_lock_of_pglist_data" */
	ldv_spin_node_size_lock_of_pglist_data = 2;
}

/* MODEL_FUNC Check that spinlock "node_size_lock_of_pglist_data" was locked and unlock it */
void ldv_spin_unlock_node_size_lock_of_pglist_data(void)
{
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_node_size_lock_of_pglist_data == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 2);
	/* NOTE Unlock spinlock "node_size_lock_of_pglist_data" */
	ldv_spin_node_size_lock_of_pglist_data = 1;
}

/* MODEL_FUNC Check that spinlock "node_size_lock_of_pglist_data" was not locked and nondeterministically lock it */
int ldv_spin_trylock_node_size_lock_of_pglist_data(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "node_size_lock_of_pglist_data" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "node_size_lock_of_pglist_data" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "node_size_lock_of_pglist_data" */
		ldv_spin_node_size_lock_of_pglist_data = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "node_size_lock_of_pglist_data" and wait until it will be unlocked */
void ldv_spin_unlock_wait_node_size_lock_of_pglist_data(void)
{
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);
}

/* MODEL_FUNC Check whether spinlock "node_size_lock_of_pglist_data" was locked */
int ldv_spin_is_locked_node_size_lock_of_pglist_data(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "node_size_lock_of_pglist_data" was locked */
	if(ldv_spin_node_size_lock_of_pglist_data == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "node_size_lock_of_pglist_data" was not locked */
int ldv_spin_can_lock_node_size_lock_of_pglist_data(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_node_size_lock_of_pglist_data();
}

/* MODEL_FUNC Check whether spinlock "node_size_lock_of_pglist_data" is contended */
int ldv_spin_is_contended_node_size_lock_of_pglist_data(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "node_size_lock_of_pglist_data" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "node_size_lock_of_pglist_data" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_node_size_lock_of_pglist_data(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_node_size_lock_of_pglist_data == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "node_size_lock_of_pglist_data" */
		ldv_spin_node_size_lock_of_pglist_data = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "node_size_lock_of_pglist_data" */
	return 0;
}
static int ldv_spin_outqueue_lock_of_tipc_conn = 1;

/* MODEL_FUNC Check that spinlock "outqueue_lock_of_tipc_conn" was not locked and lock it */
void ldv_spin_lock_outqueue_lock_of_tipc_conn(void)
{
	/* ASSERT Spinlock "outqueue_lock_of_tipc_conn" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_outqueue_lock_of_tipc_conn == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_outqueue_lock_of_tipc_conn == 1);
	/* NOTE Lock spinlock "outqueue_lock_of_tipc_conn" */
	ldv_spin_outqueue_lock_of_tipc_conn = 2;
}

/* MODEL_FUNC Check that spinlock "outqueue_lock_of_tipc_conn" was locked and unlock it */
void ldv_spin_unlock_outqueue_lock_of_tipc_conn(void)
{
	/* ASSERT Spinlock "outqueue_lock_of_tipc_conn" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_outqueue_lock_of_tipc_conn == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_outqueue_lock_of_tipc_conn == 2);
	/* NOTE Unlock spinlock "outqueue_lock_of_tipc_conn" */
	ldv_spin_outqueue_lock_of_tipc_conn = 1;
}

/* MODEL_FUNC Check that spinlock "outqueue_lock_of_tipc_conn" was not locked and nondeterministically lock it */
int ldv_spin_trylock_outqueue_lock_of_tipc_conn(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "outqueue_lock_of_tipc_conn" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_outqueue_lock_of_tipc_conn == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_outqueue_lock_of_tipc_conn == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "outqueue_lock_of_tipc_conn" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "outqueue_lock_of_tipc_conn" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "outqueue_lock_of_tipc_conn" */
		ldv_spin_outqueue_lock_of_tipc_conn = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "outqueue_lock_of_tipc_conn" and wait until it will be unlocked */
void ldv_spin_unlock_wait_outqueue_lock_of_tipc_conn(void)
{
	/* ASSERT Spinlock "outqueue_lock_of_tipc_conn" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_outqueue_lock_of_tipc_conn == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_outqueue_lock_of_tipc_conn == 1);
}

/* MODEL_FUNC Check whether spinlock "outqueue_lock_of_tipc_conn" was locked */
int ldv_spin_is_locked_outqueue_lock_of_tipc_conn(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "outqueue_lock_of_tipc_conn" was locked */
	if(ldv_spin_outqueue_lock_of_tipc_conn == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "outqueue_lock_of_tipc_conn" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "outqueue_lock_of_tipc_conn" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "outqueue_lock_of_tipc_conn" was not locked */
int ldv_spin_can_lock_outqueue_lock_of_tipc_conn(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_outqueue_lock_of_tipc_conn();
}

/* MODEL_FUNC Check whether spinlock "outqueue_lock_of_tipc_conn" is contended */
int ldv_spin_is_contended_outqueue_lock_of_tipc_conn(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "outqueue_lock_of_tipc_conn" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "outqueue_lock_of_tipc_conn" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "outqueue_lock_of_tipc_conn" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "outqueue_lock_of_tipc_conn" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_outqueue_lock_of_tipc_conn(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "outqueue_lock_of_tipc_conn" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_outqueue_lock_of_tipc_conn == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_outqueue_lock_of_tipc_conn == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "outqueue_lock_of_tipc_conn" */
		ldv_spin_outqueue_lock_of_tipc_conn = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "outqueue_lock_of_tipc_conn" */
	return 0;
}
static int ldv_spin_qitem_lock = 1;

/* MODEL_FUNC Check that spinlock "qitem_lock" was not locked and lock it */
void ldv_spin_lock_qitem_lock(void)
{
	/* ASSERT Spinlock "qitem_lock" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_qitem_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_qitem_lock == 1);
	/* NOTE Lock spinlock "qitem_lock" */
	ldv_spin_qitem_lock = 2;
}

/* MODEL_FUNC Check that spinlock "qitem_lock" was locked and unlock it */
void ldv_spin_unlock_qitem_lock(void)
{
	/* ASSERT Spinlock "qitem_lock" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_qitem_lock == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_qitem_lock == 2);
	/* NOTE Unlock spinlock "qitem_lock" */
	ldv_spin_qitem_lock = 1;
}

/* MODEL_FUNC Check that spinlock "qitem_lock" was not locked and nondeterministically lock it */
int ldv_spin_trylock_qitem_lock(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "qitem_lock" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_qitem_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_qitem_lock == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "qitem_lock" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "qitem_lock" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "qitem_lock" */
		ldv_spin_qitem_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "qitem_lock" and wait until it will be unlocked */
void ldv_spin_unlock_wait_qitem_lock(void)
{
	/* ASSERT Spinlock "qitem_lock" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_qitem_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_qitem_lock == 1);
}

/* MODEL_FUNC Check whether spinlock "qitem_lock" was locked */
int ldv_spin_is_locked_qitem_lock(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "qitem_lock" was locked */
	if(ldv_spin_qitem_lock == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "qitem_lock" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "qitem_lock" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "qitem_lock" was not locked */
int ldv_spin_can_lock_qitem_lock(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_qitem_lock();
}

/* MODEL_FUNC Check whether spinlock "qitem_lock" is contended */
int ldv_spin_is_contended_qitem_lock(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "qitem_lock" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "qitem_lock" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "qitem_lock" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "qitem_lock" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_qitem_lock(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "qitem_lock" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_qitem_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_qitem_lock == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "qitem_lock" */
		ldv_spin_qitem_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "qitem_lock" */
	return 0;
}
static int ldv_spin_siglock_of_sighand_struct = 1;

/* MODEL_FUNC Check that spinlock "siglock_of_sighand_struct" was not locked and lock it */
void ldv_spin_lock_siglock_of_sighand_struct(void)
{
	/* ASSERT Spinlock "siglock_of_sighand_struct" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Lock spinlock "siglock_of_sighand_struct" */
	ldv_spin_siglock_of_sighand_struct = 2;
}

/* MODEL_FUNC Check that spinlock "siglock_of_sighand_struct" was locked and unlock it */
void ldv_spin_unlock_siglock_of_sighand_struct(void)
{
	/* ASSERT Spinlock "siglock_of_sighand_struct" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_siglock_of_sighand_struct == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 2);
	/* NOTE Unlock spinlock "siglock_of_sighand_struct" */
	ldv_spin_siglock_of_sighand_struct = 1;
}

/* MODEL_FUNC Check that spinlock "siglock_of_sighand_struct" was not locked and nondeterministically lock it */
int ldv_spin_trylock_siglock_of_sighand_struct(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "siglock_of_sighand_struct" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "siglock_of_sighand_struct" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "siglock_of_sighand_struct" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "siglock_of_sighand_struct" */
		ldv_spin_siglock_of_sighand_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "siglock_of_sighand_struct" and wait until it will be unlocked */
void ldv_spin_unlock_wait_siglock_of_sighand_struct(void)
{
	/* ASSERT Spinlock "siglock_of_sighand_struct" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);
}

/* MODEL_FUNC Check whether spinlock "siglock_of_sighand_struct" was locked */
int ldv_spin_is_locked_siglock_of_sighand_struct(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "siglock_of_sighand_struct" was locked */
	if(ldv_spin_siglock_of_sighand_struct == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "siglock_of_sighand_struct" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "siglock_of_sighand_struct" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "siglock_of_sighand_struct" was not locked */
int ldv_spin_can_lock_siglock_of_sighand_struct(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_siglock_of_sighand_struct();
}

/* MODEL_FUNC Check whether spinlock "siglock_of_sighand_struct" is contended */
int ldv_spin_is_contended_siglock_of_sighand_struct(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "siglock_of_sighand_struct" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "siglock_of_sighand_struct" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "siglock_of_sighand_struct" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "siglock_of_sighand_struct" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_siglock_of_sighand_struct(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "siglock_of_sighand_struct" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_siglock_of_sighand_struct == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_siglock_of_sighand_struct == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "siglock_of_sighand_struct" */
		ldv_spin_siglock_of_sighand_struct = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "siglock_of_sighand_struct" */
	return 0;
}
static int ldv_spin_sk_dst_lock_of_sock = 1;

/* MODEL_FUNC Check that spinlock "sk_dst_lock_of_sock" was not locked and lock it */
void ldv_spin_lock_sk_dst_lock_of_sock(void)
{
	/* ASSERT Spinlock "sk_dst_lock_of_sock" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_sk_dst_lock_of_sock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_sk_dst_lock_of_sock == 1);
	/* NOTE Lock spinlock "sk_dst_lock_of_sock" */
	ldv_spin_sk_dst_lock_of_sock = 2;
}

/* MODEL_FUNC Check that spinlock "sk_dst_lock_of_sock" was locked and unlock it */
void ldv_spin_unlock_sk_dst_lock_of_sock(void)
{
	/* ASSERT Spinlock "sk_dst_lock_of_sock" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_sk_dst_lock_of_sock == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_sk_dst_lock_of_sock == 2);
	/* NOTE Unlock spinlock "sk_dst_lock_of_sock" */
	ldv_spin_sk_dst_lock_of_sock = 1;
}

/* MODEL_FUNC Check that spinlock "sk_dst_lock_of_sock" was not locked and nondeterministically lock it */
int ldv_spin_trylock_sk_dst_lock_of_sock(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "sk_dst_lock_of_sock" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_sk_dst_lock_of_sock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_sk_dst_lock_of_sock == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "sk_dst_lock_of_sock" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "sk_dst_lock_of_sock" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "sk_dst_lock_of_sock" */
		ldv_spin_sk_dst_lock_of_sock = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "sk_dst_lock_of_sock" and wait until it will be unlocked */
void ldv_spin_unlock_wait_sk_dst_lock_of_sock(void)
{
	/* ASSERT Spinlock "sk_dst_lock_of_sock" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_sk_dst_lock_of_sock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_sk_dst_lock_of_sock == 1);
}

/* MODEL_FUNC Check whether spinlock "sk_dst_lock_of_sock" was locked */
int ldv_spin_is_locked_sk_dst_lock_of_sock(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "sk_dst_lock_of_sock" was locked */
	if(ldv_spin_sk_dst_lock_of_sock == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "sk_dst_lock_of_sock" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "sk_dst_lock_of_sock" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "sk_dst_lock_of_sock" was not locked */
int ldv_spin_can_lock_sk_dst_lock_of_sock(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_sk_dst_lock_of_sock();
}

/* MODEL_FUNC Check whether spinlock "sk_dst_lock_of_sock" is contended */
int ldv_spin_is_contended_sk_dst_lock_of_sock(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "sk_dst_lock_of_sock" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "sk_dst_lock_of_sock" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "sk_dst_lock_of_sock" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "sk_dst_lock_of_sock" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_sk_dst_lock_of_sock(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "sk_dst_lock_of_sock" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_sk_dst_lock_of_sock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_sk_dst_lock_of_sock == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "sk_dst_lock_of_sock" */
		ldv_spin_sk_dst_lock_of_sock = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "sk_dst_lock_of_sock" */
	return 0;
}
static int ldv_spin_slock_of_NOT_ARG_SIGN = 1;

/* MODEL_FUNC Check that spinlock "slock_of_NOT_ARG_SIGN" was not locked and lock it */
void ldv_spin_lock_slock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "slock_of_NOT_ARG_SIGN" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_slock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_slock_of_NOT_ARG_SIGN == 1);
	/* NOTE Lock spinlock "slock_of_NOT_ARG_SIGN" */
	ldv_spin_slock_of_NOT_ARG_SIGN = 2;
}

/* MODEL_FUNC Check that spinlock "slock_of_NOT_ARG_SIGN" was locked and unlock it */
void ldv_spin_unlock_slock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "slock_of_NOT_ARG_SIGN" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_slock_of_NOT_ARG_SIGN == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_slock_of_NOT_ARG_SIGN == 2);
	/* NOTE Unlock spinlock "slock_of_NOT_ARG_SIGN" */
	ldv_spin_slock_of_NOT_ARG_SIGN = 1;
}

/* MODEL_FUNC Check that spinlock "slock_of_NOT_ARG_SIGN" was not locked and nondeterministically lock it */
int ldv_spin_trylock_slock_of_NOT_ARG_SIGN(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "slock_of_NOT_ARG_SIGN" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_slock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_slock_of_NOT_ARG_SIGN == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "slock_of_NOT_ARG_SIGN" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "slock_of_NOT_ARG_SIGN" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "slock_of_NOT_ARG_SIGN" */
		ldv_spin_slock_of_NOT_ARG_SIGN = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "slock_of_NOT_ARG_SIGN" and wait until it will be unlocked */
void ldv_spin_unlock_wait_slock_of_NOT_ARG_SIGN(void)
{
	/* ASSERT Spinlock "slock_of_NOT_ARG_SIGN" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_slock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_slock_of_NOT_ARG_SIGN == 1);
}

/* MODEL_FUNC Check whether spinlock "slock_of_NOT_ARG_SIGN" was locked */
int ldv_spin_is_locked_slock_of_NOT_ARG_SIGN(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "slock_of_NOT_ARG_SIGN" was locked */
	if(ldv_spin_slock_of_NOT_ARG_SIGN == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "slock_of_NOT_ARG_SIGN" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "slock_of_NOT_ARG_SIGN" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "slock_of_NOT_ARG_SIGN" was not locked */
int ldv_spin_can_lock_slock_of_NOT_ARG_SIGN(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_slock_of_NOT_ARG_SIGN();
}

/* MODEL_FUNC Check whether spinlock "slock_of_NOT_ARG_SIGN" is contended */
int ldv_spin_is_contended_slock_of_NOT_ARG_SIGN(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "slock_of_NOT_ARG_SIGN" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "slock_of_NOT_ARG_SIGN" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "slock_of_NOT_ARG_SIGN" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "slock_of_NOT_ARG_SIGN" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_slock_of_NOT_ARG_SIGN(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "slock_of_NOT_ARG_SIGN" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_slock_of_NOT_ARG_SIGN == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_slock_of_NOT_ARG_SIGN == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "slock_of_NOT_ARG_SIGN" */
		ldv_spin_slock_of_NOT_ARG_SIGN = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "slock_of_NOT_ARG_SIGN" */
	return 0;
}
static int ldv_spin_tipc_port_list_lock = 1;

/* MODEL_FUNC Check that spinlock "tipc_port_list_lock" was not locked and lock it */
void ldv_spin_lock_tipc_port_list_lock(void)
{
	/* ASSERT Spinlock "tipc_port_list_lock" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_tipc_port_list_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tipc_port_list_lock == 1);
	/* NOTE Lock spinlock "tipc_port_list_lock" */
	ldv_spin_tipc_port_list_lock = 2;
}

/* MODEL_FUNC Check that spinlock "tipc_port_list_lock" was locked and unlock it */
void ldv_spin_unlock_tipc_port_list_lock(void)
{
	/* ASSERT Spinlock "tipc_port_list_lock" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_tipc_port_list_lock == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tipc_port_list_lock == 2);
	/* NOTE Unlock spinlock "tipc_port_list_lock" */
	ldv_spin_tipc_port_list_lock = 1;
}

/* MODEL_FUNC Check that spinlock "tipc_port_list_lock" was not locked and nondeterministically lock it */
int ldv_spin_trylock_tipc_port_list_lock(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "tipc_port_list_lock" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tipc_port_list_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tipc_port_list_lock == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "tipc_port_list_lock" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "tipc_port_list_lock" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "tipc_port_list_lock" */
		ldv_spin_tipc_port_list_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "tipc_port_list_lock" and wait until it will be unlocked */
void ldv_spin_unlock_wait_tipc_port_list_lock(void)
{
	/* ASSERT Spinlock "tipc_port_list_lock" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tipc_port_list_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tipc_port_list_lock == 1);
}

/* MODEL_FUNC Check whether spinlock "tipc_port_list_lock" was locked */
int ldv_spin_is_locked_tipc_port_list_lock(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "tipc_port_list_lock" was locked */
	if(ldv_spin_tipc_port_list_lock == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "tipc_port_list_lock" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "tipc_port_list_lock" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "tipc_port_list_lock" was not locked */
int ldv_spin_can_lock_tipc_port_list_lock(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_tipc_port_list_lock();
}

/* MODEL_FUNC Check whether spinlock "tipc_port_list_lock" is contended */
int ldv_spin_is_contended_tipc_port_list_lock(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "tipc_port_list_lock" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "tipc_port_list_lock" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "tipc_port_list_lock" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "tipc_port_list_lock" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_tipc_port_list_lock(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "tipc_port_list_lock" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tipc_port_list_lock == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tipc_port_list_lock == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "tipc_port_list_lock" */
		ldv_spin_tipc_port_list_lock = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "tipc_port_list_lock" */
	return 0;
}
static int ldv_spin_tx_global_lock_of_net_device = 1;

/* MODEL_FUNC Check that spinlock "tx_global_lock_of_net_device" was not locked and lock it */
void ldv_spin_lock_tx_global_lock_of_net_device(void)
{
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be unlocked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Lock spinlock "tx_global_lock_of_net_device" */
	ldv_spin_tx_global_lock_of_net_device = 2;
}

/* MODEL_FUNC Check that spinlock "tx_global_lock_of_net_device" was locked and unlock it */
void ldv_spin_unlock_tx_global_lock_of_net_device(void)
{
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be locked */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double unlock", ldv_spin_tx_global_lock_of_net_device == 2);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 2);
	/* NOTE Unlock spinlock "tx_global_lock_of_net_device" */
	ldv_spin_tx_global_lock_of_net_device = 1;
}

/* MODEL_FUNC Check that spinlock "tx_global_lock_of_net_device" was not locked and nondeterministically lock it */
int ldv_spin_trylock_tx_global_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* ASSERT It may be bug if spinlock "tx_global_lock_of_net_device" is locked at this point */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically lock spinlock "tx_global_lock_of_net_device" */
	if (is_spin_held_by_another_thread) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" was not locked. Finish with fail */
		return 0;
	}
	else {
		/* NOTE Lock spinlock "tx_global_lock_of_net_device" */
		ldv_spin_tx_global_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}
}

/* MODEL_FUNC The same thread can not both lock spinlock "tx_global_lock_of_net_device" and wait until it will be unlocked */
void ldv_spin_unlock_wait_tx_global_lock_of_net_device(void)
{
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must not be locked by current thread */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);
}

/* MODEL_FUNC Check whether spinlock "tx_global_lock_of_net_device" was locked */
int ldv_spin_is_locked_tx_global_lock_of_net_device(void)
{
	int is_spin_held_by_another_thread;

	/* NOTE Construct nondetermined result */
	is_spin_held_by_another_thread = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "tx_global_lock_of_net_device" was locked */
	if(ldv_spin_tx_global_lock_of_net_device == 1 && !is_spin_held_by_another_thread) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is not locked */
		return 0;
	}
	else {
		/* NOTE Spinlock "tx_global_lock_of_net_device" was locked */
		return 1;
	}
}

/* MODEL_FUNC Check whether spinlock "tx_global_lock_of_net_device" was not locked */
int ldv_spin_can_lock_tx_global_lock_of_net_device(void)
{
	/* NOTE Inverse function for spin_is_locked() */
	return !ldv_spin_is_locked_tx_global_lock_of_net_device();
}

/* MODEL_FUNC Check whether spinlock "tx_global_lock_of_net_device" is contended */
int ldv_spin_is_contended_tx_global_lock_of_net_device(void)
{
	int is_spin_contended;

	/* NOTE Construct nondetermined result */
	is_spin_contended = ldv_undef_int();

	/* NOTE Nondeterministically understand whether spinlock "tx_global_lock_of_net_device" is contended */
	if(is_spin_contended) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is contended */
		return 0;
	}
	else {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is not contended */
		return 1;
	}
}

/* MODEL_FUNC Lock spinlock "tx_global_lock_of_net_device" if atomic decrement result is zero */
int ldv_atomic_dec_and_lock_tx_global_lock_of_net_device(void)
{
	int atomic_value_after_dec;

	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be unlocked (since we may lock it in this function) */
	ldv_assert("linux:kernel:locking:spinlock::one thread:double lock try", ldv_spin_tx_global_lock_of_net_device == 1);
	/* NOTE Cut all infeasible paths */
	ldv_assume(ldv_spin_tx_global_lock_of_net_device == 1);

	/* NOTE Assign result of atomic decrement */
	atomic_value_after_dec = ldv_undef_int();

	/* NOTE Atomic decrement result is zero */
	if (atomic_value_after_dec == 0) {
		/* NOTE Lock spinlock "tx_global_lock_of_net_device" */
		ldv_spin_tx_global_lock_of_net_device = 2;
		/* NOTE Finish with success */
		return 1;
	}

	/* NOTE Atomic decrement result is not zero. Finish with fail without locking spin "tx_global_lock_of_net_device" */
	return 0;
}
/* MODEL_FUNC Check that all spinlocks are unlocked at the end */
void ldv_check_final_state(void)
{
	/* ASSERT Spinlock "_xmit_lock_of_netdev_queue" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin__xmit_lock_of_netdev_queue == 1);
	/* ASSERT Spinlock "addr_list_lock_of_net_device" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_addr_list_lock_of_net_device == 1);
	/* ASSERT Spinlock "alloc_lock_of_task_struct" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_alloc_lock_of_task_struct == 1);
	/* ASSERT Spinlock "bc_lock" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_bc_lock == 1);
	/* ASSERT Spinlock "i_lock_of_inode" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_i_lock_of_inode == 1);
	/* ASSERT Spinlock "idr_lock_of_tipc_server" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_idr_lock_of_tipc_server == 1);
	/* ASSERT Spinlock "lock" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock == 1);
	/* ASSERT Spinlock "lock_of_NOT_ARG_SIGN" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_NOT_ARG_SIGN == 1);
	/* ASSERT Spinlock "lock_of_name_seq" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_name_seq == 1);
	/* ASSERT Spinlock "lock_of_reference" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_reference == 1);
	/* ASSERT Spinlock "lock_of_res_counter" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_res_counter == 1);
	/* ASSERT Spinlock "lock_of_tipc_bearer" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_tipc_bearer == 1);
	/* ASSERT Spinlock "lock_of_tipc_node" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_tipc_node == 1);
	/* ASSERT Spinlock "lock_of_tipc_port" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_tipc_port == 1);
	/* ASSERT Spinlock "lock_of_tipc_subscriber" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lock_of_tipc_subscriber == 1);
	/* ASSERT Spinlock "lru_lock_of_netns_frags" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_lru_lock_of_netns_frags == 1);
	/* ASSERT Spinlock "node_create_lock" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_node_create_lock == 1);
	/* ASSERT Spinlock "node_size_lock_of_pglist_data" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_node_size_lock_of_pglist_data == 1);
	/* ASSERT Spinlock "outqueue_lock_of_tipc_conn" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_outqueue_lock_of_tipc_conn == 1);
	/* ASSERT Spinlock "qitem_lock" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_qitem_lock == 1);
	/* ASSERT Spinlock "siglock_of_sighand_struct" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_siglock_of_sighand_struct == 1);
	/* ASSERT Spinlock "sk_dst_lock_of_sock" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_sk_dst_lock_of_sock == 1);
	/* ASSERT Spinlock "slock_of_NOT_ARG_SIGN" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_slock_of_NOT_ARG_SIGN == 1);
	/* ASSERT Spinlock "tipc_port_list_lock" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_tipc_port_list_lock == 1);
	/* ASSERT Spinlock "tx_global_lock_of_net_device" must be unlocked before finishing operation */
	ldv_assert("linux:kernel:locking:spinlock::one thread:locked at exit", ldv_spin_tx_global_lock_of_net_device == 1);
}

/* For 'linux:alloc:spinlock' rule */
int ldv_exclusive_spin_is_locked(void)
{
	/* NOTE Nondeterministically understand whether spinlock "_xmit_lock_of_netdev_queue" was locked */
	if(ldv_spin__xmit_lock_of_netdev_queue == 2) {
		/* NOTE Spinlock "_xmit_lock_of_netdev_queue" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "addr_list_lock_of_net_device" was locked */
	if(ldv_spin_addr_list_lock_of_net_device == 2) {
		/* NOTE Spinlock "addr_list_lock_of_net_device" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "alloc_lock_of_task_struct" was locked */
	if(ldv_spin_alloc_lock_of_task_struct == 2) {
		/* NOTE Spinlock "alloc_lock_of_task_struct" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "bc_lock" was locked */
	if(ldv_spin_bc_lock == 2) {
		/* NOTE Spinlock "bc_lock" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "i_lock_of_inode" was locked */
	if(ldv_spin_i_lock_of_inode == 2) {
		/* NOTE Spinlock "i_lock_of_inode" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "idr_lock_of_tipc_server" was locked */
	if(ldv_spin_idr_lock_of_tipc_server == 2) {
		/* NOTE Spinlock "idr_lock_of_tipc_server" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock" was locked */
	if(ldv_spin_lock == 2) {
		/* NOTE Spinlock "lock" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_NOT_ARG_SIGN" was locked */
	if(ldv_spin_lock_of_NOT_ARG_SIGN == 2) {
		/* NOTE Spinlock "lock_of_NOT_ARG_SIGN" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_name_seq" was locked */
	if(ldv_spin_lock_of_name_seq == 2) {
		/* NOTE Spinlock "lock_of_name_seq" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_reference" was locked */
	if(ldv_spin_lock_of_reference == 2) {
		/* NOTE Spinlock "lock_of_reference" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_res_counter" was locked */
	if(ldv_spin_lock_of_res_counter == 2) {
		/* NOTE Spinlock "lock_of_res_counter" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_bearer" was locked */
	if(ldv_spin_lock_of_tipc_bearer == 2) {
		/* NOTE Spinlock "lock_of_tipc_bearer" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_node" was locked */
	if(ldv_spin_lock_of_tipc_node == 2) {
		/* NOTE Spinlock "lock_of_tipc_node" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_port" was locked */
	if(ldv_spin_lock_of_tipc_port == 2) {
		/* NOTE Spinlock "lock_of_tipc_port" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lock_of_tipc_subscriber" was locked */
	if(ldv_spin_lock_of_tipc_subscriber == 2) {
		/* NOTE Spinlock "lock_of_tipc_subscriber" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "lru_lock_of_netns_frags" was locked */
	if(ldv_spin_lru_lock_of_netns_frags == 2) {
		/* NOTE Spinlock "lru_lock_of_netns_frags" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "node_create_lock" was locked */
	if(ldv_spin_node_create_lock == 2) {
		/* NOTE Spinlock "node_create_lock" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "node_size_lock_of_pglist_data" was locked */
	if(ldv_spin_node_size_lock_of_pglist_data == 2) {
		/* NOTE Spinlock "node_size_lock_of_pglist_data" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "outqueue_lock_of_tipc_conn" was locked */
	if(ldv_spin_outqueue_lock_of_tipc_conn == 2) {
		/* NOTE Spinlock "outqueue_lock_of_tipc_conn" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "qitem_lock" was locked */
	if(ldv_spin_qitem_lock == 2) {
		/* NOTE Spinlock "qitem_lock" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "siglock_of_sighand_struct" was locked */
	if(ldv_spin_siglock_of_sighand_struct == 2) {
		/* NOTE Spinlock "siglock_of_sighand_struct" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "sk_dst_lock_of_sock" was locked */
	if(ldv_spin_sk_dst_lock_of_sock == 2) {
		/* NOTE Spinlock "sk_dst_lock_of_sock" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "slock_of_NOT_ARG_SIGN" was locked */
	if(ldv_spin_slock_of_NOT_ARG_SIGN == 2) {
		/* NOTE Spinlock "slock_of_NOT_ARG_SIGN" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "tipc_port_list_lock" was locked */
	if(ldv_spin_tipc_port_list_lock == 2) {
		/* NOTE Spinlock "tipc_port_list_lock" is locked */
		return 1;
	}
	/* NOTE Nondeterministically understand whether spinlock "tx_global_lock_of_net_device" was locked */
	if(ldv_spin_tx_global_lock_of_net_device == 2) {
		/* NOTE Spinlock "tx_global_lock_of_net_device" is locked */
		return 1;
	}
	/* NOTE None of the spinlocks are locked */
	return 0;
}