/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_net_sock__all_locked_sockets_must_be_released(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_net_sock__double_release(int expr) {
	if (!expr)
		__VERIFIER_error();
}
