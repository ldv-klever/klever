/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_drivers_clk2__less_initial_decrement(int expr) {
	if (!expr)
		__VERIFIER_error();
}
