/*
 * Copyright (c) 2014-2016 ISPRAS (http://www.ispras.ru)
 * Institute for System Programming of the Russian Academy of Sciences
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * ee the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <verifier/common.h>
#include <linux/ldv/common.h>

enum
{
	LDV_NOT_INITIALIZED,
	LDV_INITIALIZED,
	LDV_CHANGED,
	LDV_DESTROYED
};

static int ldv_idr_idp = LDV_NOT_INITIALIZED;

/* MODEL_FUNC Init IDR. */
void ldv_idr_init_idp(void)
{
	/* ASSERT If IDR not initialized it can be initialized */
	ldv_assert("linux:lib:idr::double init", ldv_idr_idp == LDV_NOT_INITIALIZED);
	/* NOTE Initialize state_idp */
	ldv_idr_idp = LDV_INITIALIZED;
}

/* MODEL_FUNC Alloc new object in IDR. */
void ldv_idr_alloc_idp(void)
{
	/* ASSERT IDR should be initialized */
	ldv_assert("linux:lib:idr::not initialized", ldv_idr_idp != LDV_NOT_INITIALIZED);
	/* ASSERT IDR should not be destroyed */
	ldv_assert("linux:lib:idr::destroyed before usage", ldv_idr_idp != LDV_DESTROYED);
	/* NOTE Alloc in state_idp */
	ldv_idr_idp = LDV_CHANGED;
}

/* MODEL_FUNC Find object in IDR. */
void ldv_idr_find_idp(void)
{
	/* ASSERT IDR should be initialized */
	ldv_assert("linux:lib:idr::not initialized", ldv_idr_idp != LDV_NOT_INITIALIZED);
	/* ASSERT IDR should not be destroyed */
	ldv_assert("linux:lib:idr::destroyed before usage", ldv_idr_idp != LDV_DESTROYED);
	/* NOTE Find in state_idp */
	ldv_idr_idp = LDV_CHANGED;
}

/* MODEL_FUNC Remove object from IDR. */
void ldv_idr_remove_idp(void)
{
	/* ASSERT IDR should be initialized */
	ldv_assert("linux:lib:idr::not initialized", ldv_idr_idp != LDV_NOT_INITIALIZED);
	/* ASSERT IDR should not be destroyed */
	ldv_assert("linux:lib:idr::destroyed before usage", ldv_idr_idp != LDV_DESTROYED);
	/* NOTE Remove from state_idp */
	ldv_idr_idp = LDV_CHANGED;
}

/* MODEL_FUNC Destroy IDR. */
void ldv_idr_destroy_idp(void)
{
	/* ASSERT IDR should be initialized */
	ldv_assert("linux:lib:idr::not initialized", ldv_idr_idp != LDV_NOT_INITIALIZED);
	/* ASSERT IDR should not be destroyed */
	ldv_assert("linux:lib:idr::destroyed before usage", ldv_idr_idp != LDV_DESTROYED);
	/* NOTE Destroy state_idp */
	ldv_idr_idp = LDV_DESTROYED;
}

/* MODEL_FUNC Check that all module reference counters have their end values at the end */
void ldv_check_final_state(void)
{
	/* ASSERT Check if  "idp" is destroyed or not changed */
	ldv_assert("linux:lib:idr::more at exit", ldv_idr_idp == LDV_NOT_INITIALIZED || ldv_idr_idp == LDV_DESTROYED);
}