/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_lib_idr__destroyed_before_usage(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_lib_idr__double_init(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_lib_idr__more_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_lib_idr__not_initialized(int expr) {
	if (!expr)
		__VERIFIER_error();
}
