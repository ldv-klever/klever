/* http://sv-comp.sosy-lab.org/2015/rules.php */
void __VERIFIER_error(void);
void ldv_assert_linux_block_request__double_get(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_block_request__double_put(int expr) {
	if (!expr)
		__VERIFIER_error();
}
void ldv_assert_linux_block_request__get_at_exit(int expr) {
	if (!expr)
		__VERIFIER_error();
}
